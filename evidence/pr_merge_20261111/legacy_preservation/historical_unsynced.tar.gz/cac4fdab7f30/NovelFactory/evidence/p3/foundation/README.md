# P3-03 基础工程证据

本目录全部是离线工程协议证据。`example/` 中的模型结果、用量、成本、人工介入格式及事实规格明确是 `ENGINEERING_FIXTURE`；实际 provider 调用数为 0，没有真实模型或可信人工文学评分。

- `tests.xml` / `tests.json`：`tests/evaluation` 的实际执行结果。
- `failures/attempt-01-demo.json`：严格 Schema 首次拒绝错误字段的原始结果及修复说明。
- `example/experiment/`：冻结计划、追加 ledger 及原始内容对象；含失败和废弃草稿。
- `example/reviewer/`：仅 A/B 原文和共同简报的可交付材料格式。
- `example/coordinator/`：独立的条件映射；公开此工程 key 用于复核分配，不能称为实际盲评。
- `example/checkpoint.json`：账本检查点。实验外的独立保管才能防止整个证据目录同时被重写。
- `example/report.json`：`READY_FOR_REVIEW` 与 `BLOCKED_LITERARY_INFERENCE` 同时成立；未知 USD 为 null，保留预留。

详细解释、接口和复现命令见 `docs/implementation/P3_03_评测基础.md`。本目录不证明文学质量提升、中文检索准确率或 P2 完整验收。
