"""R1-B-05: one real retcon with old-source refusal and new literary derivation.

All literary decisions are explicit engineering fixtures. The new working
volume is a separately identified edition, not migration of the old volume.
"""
from copy import deepcopy
import json
from uuid import uuid4

import pytest

from editorial_helpers import approve_binding, binding_for, make_review_task, review_request
from test_narrative import assertion
from test_p2_combinations import qualified_history_release, retain
from test_release import release_request, runtime_grant, task_for

from novel_factory.application.editorial import ReviewService, memory_dependency
from novel_factory.application.narrative import NarrativeService
from novel_factory.application.planning import PlanningService
from novel_factory.application.release import ReleaseService
from novel_factory.domain.canonical import fingerprint
from novel_factory.domain.errors import DomainError
from novel_factory.fixtures import entity_value, load_fixture, point, run_command, seed_sword_history

pytestmark = [pytest.mark.postgres, pytest.mark.integration]


def uid():
    return str(uuid4())


def memory_request(k, f, binding, event_ref, text, label):
    service = ReviewService(k)
    keeper, task = make_review_task(k, f, binding, "literary_memory", role="evidence_maintainer")
    reads = [service.read_text(keeper, task["task_id"], task["generation"], ref,
        idempotency_key=label + ":read:" + str(i)) for i, ref in enumerate(binding["ordered_draft_refs"])]
    summary = k.put_artifact(keeper, binding["world_ref"]["work_id"], text.encode("utf-8"), "TEXT")
    sources = [{"kind": "EVENT", "world_ref": binding["world_ref"], "event_ref": event_ref},
        {"kind": "ARTIFACT", "artifact_ref": reads[0]["text_ref"], "span": reads[0]["span"]}]
    candidate = {"schema_version": "2.0", "candidate_id": uid(), "task_id": task["task_id"], "generation": task["generation"],
        "world_ref": binding["world_ref"], "memory_kind": "LITERARY_MEMORY", "plane": "LITERARY", "audience": "WRITER",
        "actor_id": f["ids"]["protagonist"], "source_refs": sources,
        "counterevidence_refs": [{"kind": "ARTIFACT", "artifact_ref": reads[1]["text_ref"], "span": reads[1]["span"]}],
        "source_coverage": "COMPLETE", "coverage_note": "工程夹具：两场精确原文实际交付；解释未变成心理事实。",
        "summary_ref": summary, "method_revision_sha256": fingerprint("B05-actual-source-reading-v1"),
        "dependency_fingerprint": "0" * 64, "narrative_revision_id": binding["narrative_revision_id"],
        "entry_kind": "RELATIONSHIP_ASYMMETRY", "unresolved_items": ["行为意义仍可有反解释；本测试不宣称文学质量。"]}
    candidate["dependency_fingerprint"] = memory_dependency(candidate, binding["ordered_draft_refs"])
    request = {"schema_version": "2.1", "candidate": candidate, "source_draft_refs": binding["ordered_draft_refs"],
        "coverage_refs": [r["coverage_ref"] for r in reads], "idempotency_key": label + ":memory"}
    return {"principal": keeper, "task": task, "reads": reads, "request": request}


def requalified_edition(k, old_f, old_accepted, new_world, new_event):
    """Explicit new volume/plan, with same scene identity and recorded prior drafts."""
    p = old_f["principal"]
    planning, narrative, release = PlanningService(k), NarrativeService(k), ReleaseService(k)
    with k.db.uow(write=False) as repo:
        original_contract = k.artifact(repo, old_f["plan"]["volume_contract_ref"], new_world["work_id"])["payload"]
    volume = deepcopy(original_contract)
    volume.update(volume_id=uid(), contract_revision_id=uid(), input_world_ref=new_world,
        creative_brief="显式新工作卷：依据修订后的赠剑历史重新派生文学来源；不是原volume迁移。",
        narrative_intents=["保持两次叙述的发生身份，但重新判断赠与后的关系意义"],
        dependency_fingerprint=fingerprint({"world": new_world, "source_release_volume": old_f["volume_id"]}))
    volume_ref = planning.save_volume_contract(p, volume, "b05-new-volume")
    plan = deepcopy(old_f["plan"])
    plan.update(plan_id=uid(), plan_revision_id=uid(), volume_id=volume["volume_id"], input_world_ref=new_world,
                volume_contract_ref=volume_ref, prior_plan_ref=None)
    for node in plan["nodes"]:
        node.update(node_id=uid(), goal="重新呈现赠与，不能把旧借用资格带入新历史")
    plan["decision"] = {"reason": "retcon后显式开启新工作卷，旧卷发布保持不变",
        "considered_options": [{"option_id": uid(), "summary": "新任务、新原文、新事件锚点", "disposition": "SELECTED", "reason": "保持跨分支与旧发布边界"}]}
    plan_ref = planning.save_plan(p, plan, "b05-new-plan")
    planning.adopt_plan(p, new_world, plan_ref, None, "b05-new-adoption")
    narrative_id = uid()
    batch = deepcopy(old_f["batch_request"])
    batch.update(world_ref=new_world, volume_id=volume["volume_id"], plan_ref=plan_ref,
                 narrative_revision_id=narrative_id, arrangement_version="retcon-edition-1")
    batch_ref = release.create_writing_batch(p, batch, "b05-new-writing-batch")
    f = {**old_f, "world_ref": new_world, "volume_id": volume["volume_id"], "narrative_revision_id": narrative_id,
         "plan": plan, "plan_ref": plan_ref, "batch_request": batch, "batch_ref": batch_ref, "scenes": [], "scene_refs": []}
    accepted = []
    for i, text in enumerate(["那次赠剑时，她看见他收紧了手。", "他又想起那次赠剑时收紧的手，仍不敢替她解释。"]):
        scene = deepcopy(old_f["scenes"][i])
        scene.update(plan_ref=plan_ref, plan_node_ids=[plan["nodes"][i]["node_id"]], batch_ref=batch_ref,
                     prior_scene_ref=old_f["scene_refs"][i], required_event_refs=[new_event])
        scene["scene_contract"].update(input_world_ref=new_world, event_refs=[new_event], narrative_revision_id=narrative_id,
            arrangement_version="retcon-edition-1", dependency_fingerprint=fingerprint({"world": new_world, "plan": plan_ref, "scene": i}))
        scene["entry_checks"][0].update(check_id=uid(), expected_value=entity_value(f["ids"]["friend"]))
        scene_ref = narrative.save_scene(p, scene, "b05-scene:" + str(i))
        f["scenes"].append(scene); f["scene_refs"].append(scene_ref)
        writer = runtime_grant(k, f, "writer")
        task = task_for(k, f, writer, [plan_ref, batch_ref, scene_ref, old_accepted[i]["draft_ref"]], story_time=point(25, 1))
        planning.bind_task_for_controller(p, task["task_id"], task["generation"], plan_ref, scene["plan_node_ids"], "b05-writer-plan:" + str(i))
        release.bind_writer_task(writer, task["task_id"], task["generation"], scene_ref, [], "b05-writer-batch:" + str(i))
        draft_ref = narrative.store_draft(writer, task["task_id"], task["generation"], scene_ref, text, "b05-draft:" + str(i),
                                         prior_draft_ref=old_accepted[i]["draft_ref"])
        reader = runtime_grant(k, f, "reviewer")
        rt = task_for(k, f, reader, [draft_ref], "fact", story_time=point(25, 1))
        narrative.bind_reader_task(p, rt["task_id"], rt["generation"], [draft_ref], "b05-extract-bind:" + str(i))
        delivery = narrative.read_text(reader, rt["task_id"], rt["generation"], draft_ref)
        extraction = narrative.submit_extraction(reader, rt["task_id"], rt["generation"], draft_ref, delivery["delivery_ref"],
            [assertion(text, classification="EXISTING_EVENT_PRESENTATION", event_ref=new_event)], "b05-extraction:" + str(i))
        report = narrative.reconcile(p, draft_ref, extraction, new_world, "b05-reconcile:" + str(i))
        assert report["status"] == "CLEAR"
        acceptance = narrative.accept_narrative(p, draft_ref, report["reconciliation_ref"], new_world, "b05-text-accept:" + str(i))
        accepted.append({"draft_ref": draft_ref, "acceptance_ref": acceptance, "reconciliation_ref": report["reconciliation_ref"],
                         "extraction_ref": extraction, "text": text})
    binding = {**binding_for(f, accepted), "arrangement_version": "retcon-edition-1"}
    return f, accepted, binding


def test_retcon_rederives_literary_sources_in_explicit_new_working_volume(kernel_env, tmp_path):
    k = kernel_env["kernel"]
    f = seed_sword_history(k, load_fixture(k, "r1_sword"))
    p, old = f["principal"], f["world_ref"]
    f, accepted, old_release_request, old_receipt = qualified_history_release(k, f)
    old_binding = {**binding_for(f, accepted), "arrangement_version": "combo-1"}
    narrative, review, release = NarrativeService(k), ReviewService(k), ReleaseService(k)
    old_export = release.export_release(p, old["work_id"], old_receipt["release_ref"])
    old_event_ref = f["loan"]["receipt"]["accepted_event_refs"][0]
    old_memory = memory_request(k, f, old_binding, old_event_ref, "借用留下将来归还的期待；收紧手的意义仍未确定。", "old")
    old_memory_ref = review.save_memory(old_memory["principal"], old_memory["request"])
    with k.db.uow(write=False) as repo:
        before = deepcopy(k.revision(repo, old))
        replacement = deepcopy(repo.one("events", {"event_version_id": old_event_ref["event_version_id"]})["payload"])
    replacement.update(event_version_id=uid(), representation_id=uid())
    replacement["effects"].append({"kind": "RELATION_SET", "effect_key": "b05:gift:owner", "subject_id": f["ids"]["sword"],
        "predicate": "legal_owner", "object_id": f["ids"]["friend"], "value_status": "VALUE"})
    fork = k.fork(p, old, "REPAIR", "b05-repair-fork")
    reviewer = k.issue_grant(p, old["work_id"], role_id="control_operator", branch_ids=[fork["branch_id"]],
        capabilities=["READ", "APPROVE", "REPAIR"], planes=["WORLD"], max_story_time=point(100))["principal"]
    repaired = run_command(k, p, fork, "REPAIR_EVENT", {"occurrence_id": replacement["occurrence_id"],
        "replacement_event": replacement, "reason": "B05工程修订：将借用改为赠与，保留旧事件及旧卷"}, reviewer=reviewer, key="b05-retcon")
    new = k.promote(p, old, repaired["world_ref"], "b05-promote")
    new_event_ref = repaired["receipt"]["accepted_event_refs"][0]
    assert new_event_ref["occurrence_id"] == old_event_ref["occurrence_id"]
    assert new_event_ref["event_version_id"] != old_event_ref["event_version_id"]
    with k.db.uow(write=False) as repo, pytest.raises(DomainError) as stale_plan:
        narrative.validate_for_acceptance(repo, p, accepted[0]["draft_ref"], accepted[0]["reconciliation_ref"], old)
    assert stale_plan.value.code == "STALE_PLAN"
    new_f, new_accepted, new_binding = requalified_edition(k, f, accepted, new, new_event_ref)
    assert new_f["volume_id"] != f["volume_id"]

    old_reader = old_memory["principal"]
    with pytest.raises(DomainError) as old_reader_reuse:
        review.read_text(old_reader, old_memory["task"]["task_id"], old_memory["task"]["generation"],
                         new_accepted[0]["draft_ref"], idempotency_key="old-reader-new-text")
    assert old_reader_reuse.value.code == "VIEW_DENIED"
    # The old fixed history remains an authorized historical read, not a source
    # qualification for the promoted branch.
    historical = review.read_text(old_reader, old_memory["task"]["task_id"], old_memory["task"]["generation"],
                                 accepted[0]["draft_ref"], idempotency_key="old-reader-old-text")
    assert historical["text"] == accepted[0]["text"]
    assigned_old = {**new_binding, "literary_refs": [old_memory_ref]}
    new_reader, new_rt = make_review_task(k, new_f, assigned_old, "scene_draft", role="writer")
    with pytest.raises(DomainError) as old_memory_reuse:
        review.read_memory_for_task(new_reader, new_rt["task_id"], new_rt["generation"], new_rt["context_bundle_id"], old_memory_ref)
    assert old_memory_reuse.value.code == "MEMORY_REVALIDATION_REQUIRED"

    fresh = memory_request(k, new_f, new_binding, new_event_ref,
        "赠与取消了必然归还的前提；紧握与迟疑仍可有多种解释，两条声线没有被产权修订抹平。", "new")
    invalid_coverage = deepcopy(fresh["request"])
    invalid_coverage.update(coverage_refs=old_memory["request"]["coverage_refs"], idempotency_key="old-coverage-new-memory")
    with pytest.raises(DomainError) as old_coverage:
        review.save_memory(fresh["principal"], invalid_coverage)
    assert old_coverage.value.code == "INVALID_READING_COVERAGE"
    invalid_event = deepcopy(fresh["request"])
    invalid_event["candidate"]["source_refs"][0]["event_ref"] = old_event_ref
    invalid_event["candidate"]["dependency_fingerprint"] = memory_dependency(invalid_event["candidate"], invalid_event["source_draft_refs"])
    invalid_event["idempotency_key"] = "old-event-new-memory"
    with pytest.raises(DomainError) as old_event:
        review.save_memory(fresh["principal"], invalid_event)
    assert old_event.value.code == "INVALID_EVIDENCE"
    fresh_ref = review.save_memory(fresh["principal"], fresh["request"])
    assert review.save_memory(fresh["principal"], fresh["request"]) == fresh_ref
    new_binding["literary_refs"] = [fresh_ref]

    fact_reader, fact_task = make_review_task(k, new_f, assigned_old, "fact")
    reads = [review.read_text(fact_reader, fact_task["task_id"], fact_task["generation"], ref,
        idempotency_key="bad-memory-review:" + str(i)) for i, ref in enumerate(new_binding["ordered_draft_refs"])]
    old_memory_review = review_request(assigned_old, fact_task, [r["coverage_ref"] for r in reads],
        "SCENE", "FACT", [new_binding["ordered_draft_refs"][0]])
    with pytest.raises(DomainError) as old_memory_binding:
        review.submit_review(fact_reader, old_memory_review)
    assert old_memory_binding.value.code == "EDITORIAL_BINDING_MISMATCH"
    reused_approval = release_request(new_f, new_binding, old_release_request["editorial_approval_ref"])
    with pytest.raises(DomainError) as old_approval:
        release.freeze(p, reused_approval, "b05-reuse-old-approval")
    assert old_approval.value.code == "EDITORIAL_BINDING_MISMATCH"
    writer, wt = make_review_task(k, new_f, new_binding, "scene_draft", role="writer")
    delivered = json.loads(review.read_memory_for_task(writer, wt["task_id"], wt["generation"], wt["context_bundle_id"], fresh_ref))
    assert delivered["source_world_ref"] == new
    assert delivered["source_refs"][0]["event_ref"] == new_event_ref
    assert delivered["authority"] == "DERIVED_LITERARY_INTERPRETATION_NOT_WORLD_FACT_OR_ACTOR_BELIEF"
    assert delivered["interpretation"].startswith("赠与取消") and delivered["counterevidence_refs"]
    proof = approve_binding(k, new_f, new_binding)
    new_receipt = release.freeze(p, release_request(new_f, new_binding, proof["approval_ref"]), "b05-new-edition-release")
    assert release.export_release(p, old["work_id"], old_receipt["release_ref"]) == old_export
    with k.db.uow(write=False) as repo:
        after = k.revision(repo, new)
        assert k.head(repo, old["work_id"]) == new
        assert len(after["selection"]) == len(before["selection"])
        assert before["snapshot"]["cognitions"] == after["snapshot"]["cognitions"]
        assert before["snapshot"]["resources"] == after["snapshot"]["resources"]
        assert k.artifact(repo, old_memory_ref, old["work_id"])["payload"] == old_memory["request"]
        for old_draft, new_draft in zip(accepted, new_accepted, strict=True):
            assert k.artifact(repo, new_draft["draft_ref"], old["work_id"])["payload"]["prior_draft_ref"] == old_draft["draft_ref"]
        for volume_id, receipt in ((f["volume_id"], old_receipt), (new_f["volume_id"], new_receipt)):
            assert repo.one("selections", {"work_id": old["work_id"], "selection_kind": "RELEASE:" + volume_id})["artifact_ref"] == receipt["release_ref"]
    retain("B05_retcon_literary_source_rederivation", {"criterion": "R1-B-05", "old_world_ref": old, "new_world_ref": new,
        "old_volume_id": f["volume_id"], "new_working_volume_id": new_f["volume_id"],
        "edition_semantics": "EXPLICIT_NEW_VOLUME_NOT_SAME_VOLUME_MIGRATION", "old_event_ref": old_event_ref, "new_event_ref": new_event_ref,
        "old_memory_ref": old_memory_ref, "new_memory_ref": fresh_ref,
        "old_memory_dependency": old_memory["request"]["candidate"]["dependency_fingerprint"],
        "new_memory_dependency": fresh["request"]["candidate"]["dependency_fingerprint"],
        "new_source_draft_refs": fresh["request"]["source_draft_refs"], "new_reading_coverage_refs": fresh["request"]["coverage_refs"],
        "old_release_ref": old_receipt["release_ref"], "new_release_ref": new_receipt["release_ref"],
        "original_release_export_sha256": fingerprint(old_export), "old_release_unchanged": True,
        "rejections": {"old_plan_qualification": stale_plan.value.code, "old_reader_new_text": old_reader_reuse.value.code,
            "old_memory_new_task": old_memory_reuse.value.code, "old_coverage_new_memory": old_coverage.value.code,
            "old_event_anchor": old_event.value.code, "old_memory_new_review": old_memory_binding.value.code, "old_approval_new_release": old_approval.value.code},
        "world_effects_from_rederivation": 0, "external_model_calls": 0, "literary_judgments": "EXPLICIT_ENGINEERING_FIXTURES"}, tmp_path)
