# 客户端生成能力校准

**证据类别：`GENERATOR_CALIBRATION_ONLY`。NovelFactory 容量结论与业务提交数均为 `NOT_APPLICABLE`。**

## 固定条件

执行仓库 HEAD：`008fccf23291c6f74693e450a88c224a436be7f6`。Python 3.12.14、HTTPX 0.28.1、Uvicorn 0.54.0；AMD EPYC 9V74 共享宿主暴露 9 个逻辑 CPU；客户端 affinity 6–7，独立诊断服务器 affinity 8。固定 seed 7、1000 个合成客户端、5 轮共 5000 个请求、计划 1000 RPS、HTTPX 连接池 256、30 秒超时。直接复用未经修改的 `benchmarks.p3_open_arrival.offer`；该工具没有重试。

独立 ASGI/Uvicorn 进程只读完请求 body 并返回固定 JSON 字节，不连接 PostgreSQL，不验证身份/权限，不执行业务、不写世界。每请求 body 为 627 字节。2104 字节响应来自已下载实际 CI 负载：筛选 `label=overload,status=200` 共 916 条，最小/中位/最大均为 2104。64 字节用于乐观传输参考。两个大小交替执行，各重复 2 次，全部保留。

## 实测

| 响应 body | 次数 | header-start RPS | 完成窗口 s | 调度延迟 p95 ms | 全请求延迟 p99 ms | 客户端 CPU s | 服务器 CPU s | HTTP 200/字节匹配 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 64 | 1 | 197.42 | 25.386 | 19000.85 | 2116.03 | 25.354 | 1.668 | 5000/5000 |
| 2104 | 1 | 203.65 | 24.602 | 18265.63 | 2202.74 | 24.577 | 1.501 | 5000/5000 |
| 64 | 2 | 212.01 | 23.644 | 16904.42 | 2285.23 | 23.608 | 1.813 | 5000/5000 |
| 2104 | 2 | 241.31 | 20.779 | 14529.37 | 2269.50 | 20.737 | 1.642 | 5000/5000 |

所有 20,000 次请求都保留原始条目，index 完整无重复，每个合成 Agent 恰好 5 次；HTTP 均为 200，响应 body 哈希及长度均匹配；服务端请求/响应数、双边请求/响应 body 总字节数完全对账，无传输异常、断连或 handler error。每轮请求 body 合计 3,135,000 字节，64 字节档响应合计 320,000 字节，2104 字节档为 10,520,000 字节。

客户端 CPU/窗口约 99.80%–99.90% 单核；诊断服务器约 6.10%–7.90% 单核。同一客户端在此固定 CPU 预算和共享宿主上，即便连接简单固定回包服务器也未能提供 1000 次/秒 header-start。这证明本组规模测试存在客户端提供速率限制，不能将实际发出的约 197–241 RPS 等同于已给服务施加 1000 RPS，也不能据此认定 NovelFactory 只有该容量或没有服务端瓶颈。

## 解释边界与元数据勘误

header-start 是 HTTPcore 发送请求头开始事件，并非抓包或服务端已接受请求的证明。延迟包含客户端调度及连接池等待；body 字节不含 HTTP 头或 TCP framing。短窗口和共享宿主无法建立持续容量 SLO。后轮数值波动不能据此推断大响应提高吞吐。该结果不能进入原 capacity gate，不能增加业务成功或正式世界提交数，原目标保持未通过状态。

原始 JSON 的 `environment.load_client_location/api_processes/api_server_threads` 误继承通用 P2 `hardware()` 的静态拓扑说明。实际执行拓扑为独立进程，见每轮 server affinity 与执行源码；当前脚本已仅修正这段元数据，测量代码与 offer 未变。原始 JSON 未覆盖，执行时源码已快照保留。`ru_maxrss` 是进程生命周期峰值，可能包含启动/exec 继承的历史峰值，不作为单轮内存使用或泄漏结论。

## 可复现命令

```bash
taskset -c 6-8 .venv/bin/python -m benchmarks.client_calibration \
  --response-bytes 64 2104 --repeats 2 --seed 7 \
  --client-cpus 6 7 --server-cpus 8 \
  --size-source /path/to/actual-ci/run-1/load.json \
  --output /new/path/client-calibration.json
```

运行目录为 PR3 工作树；输出必须使用新路径，脚本不会覆盖既有文件。源 CI JSON 路径、SHA256、实际执行源码快照 hash、修正后脚本 hash、完整复核摘要见 `summary.json`。原始 20,000 条记录见 `calibration.json`。
