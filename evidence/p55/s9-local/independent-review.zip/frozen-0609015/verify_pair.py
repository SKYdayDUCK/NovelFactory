"""Verify actual PostgreSQL writes and authorization in both P3 benchmark arms."""
from contextlib import nullcontext
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from sqlalchemy import text
from benchmarks.p3_context_comparison import baseline_methods, baseline_module, paired_inputs
from benchmarks.context_paired_profile import capture_persisted_material
from novel_factory.application.queries import WorldQueryService
from novel_factory.domain.errors import DomainError

output = Path(__file__).with_name("pair-auth.json")
records = {}
with TemporaryDirectory() as root:
    temporal, _ = baseline_module("src/novel_factory/domain/temporal.py", "novel_factory.domain._review_p3_t", root)
    repository, _ = baseline_module("src/novel_factory/infrastructure/repository.py", "novel_factory.infrastructure._review_p3_r", root)
    with paired_inputs(root, 100, 1) as (arms, world, inputs):
        request = inputs[20, 0]
        for arm, (kernel, meter) in arms.items():
            wr = world["world_ref"]
            owner = world["principal"]
            other = kernel.issue_grant(owner, wr["work_id"], role_id="control_operator", branch_ids=[wr["branch_id"]], capabilities=["READ"], planes=["WORLD"])["principal"]
            ctx = baseline_methods(temporal.point_key, repository.KernelRepository.ancestor) if arm == "baseline" else nullcontext()
            service = WorldQueryService(kernel)
            with ctx:
                def count():
                    with kernel.db.uow(write=False) as repo:
                        return repo.conn.scalar(text("SELECT count(*) FROM nf_contexts WHERE task_id=:task AND generation=:gen"), {"task":request["task_id"], "gen":request["generation"]})
                def denied():
                    try:
                        service.context_compile(other, request)
                    except DomainError as error:
                        assert error.code in {"VIEW_DENIED", "AUTHORIZATION_DENIED", "CAPABILITY_DENIED"}
                        return error.code
                    raise AssertionError("Different READ-only principal compiled a context")
                asserts_before = [count(), denied(), count()]
                assert asserts_before[0] == asserts_before[2] == 0
                meter.reset()
                compiled = service.context_compile(owner, request)
                sql = meter.result()
                assert sql["statement_kinds"]["INSERT"] > 0 and sql["dependency_insert_statements"] > 0
                assert count() == 1
                rejection_after = denied()
                replay = service.context_compile(owner, request)
                assert replay == compiled and count() == 1
                with kernel.db.uow(write=False) as repo:
                    dbname = repo.conn.scalar(text("SELECT current_database()"))
                facts = capture_persisted_material(kernel, world, request, compiled)
                records[arm] = {"database":dbname, "task_id":request["task_id"], "generation":request["generation"], "bundle_id":facts["context_bundle_id"], "facts_sha256":facts["full_fact_sha256"], "guards_sha256":facts["guard_material_sha256"], "source_count_before":asserts_before[0], "source_count_after":count(), "initial_sql":sql, "wrong_principal_before":asserts_before[1], "wrong_principal_after":rejection_after, "authorized_repeat_equal":True}
for key in ("task_id", "generation", "facts_sha256", "guards_sha256"):
    assert records["baseline"][key] == records["candidate"][key]
for key in ("database", "bundle_id"):
    assert records["baseline"][key] != records["candidate"][key]
output.write_text(json.dumps(records, indent=2) + "\n")
