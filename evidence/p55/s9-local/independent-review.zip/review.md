# S9 语义依赖与接受屏障独立复核

## 检查点与方法

原生回放在冻结树 bd410ccfd480166c32e251da9886f81e489bd8d8（prefinal-a）进行。业务文件保持冻结，只复制了新编写的回归测试。环境为 Python 3.12.14、PostgreSQL 17.11、Alembic 0015、fsync 与 synchronous_commit 均启用。流水线 25 个原有关键场景通过的记录在相邻 ../prefinal-a-key/junit.xml。随后另选不受现有测试约束的输入，先核对查询交付给调用方的实际内容，再用原候选的证书正式调用 Kernel.accept。反例未手工插入冲突、修改数据表或伪造读集。修复前的原始输出留在 before-five.log 与 before-five/junit.xml。流水线通过和五个补充失败的记录分别对应不同输入集。

## 分项复核

下表中的 application/ 与 domain/ 路径均以仓库 src/novel_factory/ 为根；其他源文件以仓库根为起点，证据目录相对于本报告所在位置。

| 检查对象 | 原始来源与调用入口 | 验证与边界 |
| --- | --- | --- |
| 版本与来源 | application/message_sources.py 的 save_version 写原有制品版本和操作回执；application/kernel.py 的事件验证在关系建立时核对完整 ArtifactRef、工件类别与知识载体；domain/world.py 负责独立认知记录 | test_s9_message_narrative.py 对并发重复建版、两个分支保留原信、人类审核角色权限及历史信念做断言。test_s9_dependencies.py 采用真实 SET_RELATION、RECORD_COGNITION 及查询检查真假变化。发现旧式 TEXT 和合法不同空格 JSON 引用都能正式建关系，而材料交付对其漏登记，见下表。 |
| 权威观察与冲突 | application/queries.py 的 _delivery_check 与 context_compile 登记实际发出项；application/kernel.py 的 propose、prepare、accept 依次记录提案、查依赖、记录已接受变更。application/semantic_dependencies.py 的 _MATCH_INDEXED、_detect、check_task_dependencies 独立于 Redis 工作进度 | test_s9_dependencies.py 覆盖负查询、先消费后登记、跨版本因果、角色历史、角色权限、跨分支、历史输入及同一排他目标的两个预登记候选。迁移 0013 的 GIN 和历史读索引可在 benchmarks/p55_semantic_index.py 的实际 EXPLAIN ANALYZE 中追踪。打开自然语言假设进入保守审核。旧证书对图边自动关闭及间接前沿变化有三个实证漏检，见下表。 |
| 正文提交与发布 | application/narrative.py 的 _validate_for_acceptance 重新验证写作者和断言提取任务两份冻结观察，复核原始证据与当前世界。accept_narrative 在 work、branch 加锁后再检查。application/release.py 的 _load_acceptance 复用同一屏障，freeze 在锁内重新核对完整材料。get_release 按旧制品引用读取 | test_s9_message_narrative.py 在正文不含显式硬前提词、初始对齐 CLEAR 的情况下，变更作者实际读取的持有关系，正式接受失败且保留正文。test_release.py 覆盖冻结竞态、丢回执、审批撤销和历史清单不可变；test_history_repair.py 覆盖原历史保留、受控修订和提升。独立复核未对每种源依赖在发布锁最后一步重新注入竞态。 |
| 统计与私密性 | application/audit_log.py 的 conflict 在业务事务内使用 case/receipt 身份写审计，Redis 只带索引。application/statistics.py 的 handle 从 PG 取证并以 metric_version、event_id 去重。rebuild、verify 对固定 cut 重算。recent_conflicts、trace 和统计读取在读之前校验分支 ADMIN | test_s9_conflict_statistics.py 首个测试直接注入合成审计输入，验证解释器，另两项使用真实登记、重算与角色 stdio。test_p55_statistics.py 覆盖晚到事务、版本、失联追平以及费用来源。DETECTED 在 guard 分类阶段产生；有些候选后来重验证证明值未变，confirmed_by_guard 表示确定性屏障命中，不等同业务事实发生改变。模型次数与费用须使用实际回执，实验的 0 次模型调用不代表线上节省了 Token。 |
| 归因与比较 | application/conflict_resolution.py 的自动执行回执写处理结果和时长。基于不可变重算回执和新任务代数归因后续完成或调用；_usage 区分本地夹具、主机和供应商计价以及未结算 | 耗时是有样本的工作线程处理时间。审核等待和外部账单没有据此估算。四臂 benchmark 的语义 oracle 只有三个构造任务，重复统计延时用同一组输入。生产 false_positives、false_negatives 和无效返工率保留未测；不能从样例推论任意叙事的召回率。 |

## 修复前可复现的五个错误接受

通用命令为 `python scripts/with_postgres.py --log-dir <pg目录> --migrate -- python -m pytest -q tests/integration/test_s9_query_coverage.py --junitxml=<结果路径>`。五项均在正式 Kernel.accept 处得到“DID NOT RAISE DomainError”。这些变化发生在独立于候选转粮命令的世界状态上。

| pytest 参数 | 原生查询与检验 |
| --- | --- |
| implicit_edge_closure | 阅读北门→剑→铁匠的两条图边；DESTROY_ITEM 自动关闭持有关系；新世界同一查询只返回一条。 |
| scoped_timeline | 一名角色的 scope_id 定位北门，ADVANCE_SCOPE 只推进北门。角色时间线 coverage 从 PARTIAL 变为 COMPLETE。 |
| visited_graph_frontier | 图的种子北门和末端铁匠已覆盖，推进中间节点剑的前沿，实际图查询的 coverage 从 PARTIAL 变为 COMPLETE。 |
| existing_text | 通过既有 Kernel.put_artifact 制作 TEXT 并将版本真实绑定为消息正文。另一任务获得授权并读取原文，此后同一载体的真实性发生变化。 |
| spaced_version_reference | 通过 MessageSourceService 得到版本，将合法、有空白的 JSON 引用绑定为正文。另一任务授权读同一内容，之后真实性变化。 |

## 当前输入的修复复验与来源对照

重新启动干净的 PG17.11 并迁移后，本次独立选择的 7 个模块共 41 项通过，零失败、零跳过。原始日志在 projection-fix.log，完整 JUnit 在 projection-fix/junit.xml，启动命令与 PG 身份在 projection-fix/postgres_session.json。五个反例都真正触发正式接受拒绝；其余覆盖原有发布流程、来源、信念、正文、审查、统计与初始升级。该次测试针对修复开发树，不能充当其后 0016 升级的冻结提交验证。

修复后，WorldQueryService._covered 记录当前查询实际检验的作用域，并随遍历、统一查询的内存缓存和批处理结果携带。change_keys 在终止生命周期时登记会受其隐含关闭影响的谓词范围。record_material_read 在已授权阅读后按快照中有效载体关系比较结构化 ArtifactRef，因此以既有 TEXT 制作的消息和不同合法 JSON 空白都能保留来源依赖。

随后的统计增量还增加了 StatisticsService.labelled_conflicts。固定工作、分支、审计 cut、受检 task/generation/world 以及独立审批者签署的 EVIDENCE 后，可重算样本的实际冲突、TP/TN/FP/FN 和无效重做分数。它核对实际重新领取的 RUNNING 代数和输入版本。test_independent_label_set_replays_on_cut_and_excludes_self_labels 以两个真实已知任务验证原始标签、反转标签、同 cut 重放和生产者自签被拒。该专项原始记录为相邻 ../s9-labelled-quality/junit.xml。默认无标签的生产投影仍保留未测。

## 历史兼容

0016_p55_observed_scopes 从旧 WorldRef 复演查图和时间线实际覆盖的前沿，以结构化 ArtifactRef 恢复消息来源，按原事件补上终止生命周期的隐含谓词范围；补充索引及有限的重扫提示与原观察、世界和接受回执分开存储。旧观察真正参与 check_task_dependencies，不能只靠后台重扫更新结论。tests/integration/test_s9_upgrade.py 的 test_observed_scopes_upgrade_fences_existing_graph_and_material_candidates 从已发布的 ef371a32c6c8df5fea41b96702c9903132b85737 启动真实 0015 代码和数据库，旧版完整接受两张原证书后在 savepoint 回滚，把原输入留到升级。迁移后比对现有业务表的摘要；两张旧证书均被同步拦截，补扫恢复两个任务的冲突登记，当前 HEAD 保持原世界。该专项与 0014 升级同跑，第一次 2 项皆通过，原始记录为相邻 ../s9-0016-upgrade/junit.xml。此处的两项跨历史检查覆盖前沿与消息材料代表路径；五个新输入变体另在本报告的测试中逐项检查。

另一次独立新建 PG17.11 的组合运行包含 0016 及真实旧版本升级，共 43 项通过、零跳过，耗时 58.36 秒。原始记录在 final-0016/junit.xml。它运行期间业务树仍在变更，因此只作开发树复验。verified-files.sha256 是运行期间的一次源文件采样；后续冻结提交应以独立运行的起止记录为准。

## 冻结提交的独立复验

最终独立检查点为 c63483bd04af9f2c05981471dea3fa659e87664b，tree 为 6f34a4efa6d75542ab925ced7a765b4b7dc9e53a。另起 detached worktree，并根据锁文件离线安装该 worktree 自己的虚拟环境，验证实际导入的 Kernel 来自该目录。开始及结束两次 git status --porcelain 均为空。独立 PG17.11 从空库升级，fsync 与同步提交均打开。上述七个业务模块正式运行 **44 passed，0 failed，0 errors，0 skipped**，pytest 输出 70.19 秒。运行证据为 frozen-c63483b/{start.json,end.json,postgres_session.json,junit.xml,run.log}。

该 44 项包括五个旧证书错误接受的反例，两个历史数据库迁移，正文发布链、角色 stdio 拒绝旁观审计、独立标注重算及全部九项修正策略执行测试。本次还验证了章节草稿正文被另一个载体选作信件时，授权读者从 read_text 读到该版本后，其硬前提能随载体属性改变被同步拦截。全库业务测试、真实 Redis 故障恢复与物理 PITR 的证据由发布运行另行保存，本次独立 PostgreSQL 复核没有将它们重复计入 44 个样本。

## 最终 0609015 的差异与重验

最终提交为 0609015e7f34ad7a727037236bf9bd969baaa484，tree 为 420d36e7dcd9a3e7328de45f48c035e3eccc7541。相对 c63483b 只变动 benchmarks/p3_context_comparison.py 与 docs/P5.6_开发阶段与验收计划.md。后者修正权限场景里的错字。前者将每个请求的 task、generation、清单和授权状态冻结一次，再用 PostgreSQL 模板复制到两套隔离数据库；两个分组独立执行权限检查、编译事务和落盘。计时分组只替换所声明的两项基线算法；单独的 profiler 使用另外预留的任务。两组共用同一临时内容寻址对象目录，完整权限、上下文与业务回执各存在本组的数据库。综合运行在 1、20、100 个主体、每档 5 次重复的 15 对输入上比较，适用于这个构造工作负载。

独立读取并验算原参数运行的全部 15 对物料：一对内是同 task 和 input_manifest_ref，完整 facts、guard_material 与 scope_row_count 等价，context_bundle_id 均不同；30 次首次编译每次各有 49 条 SQL，均包含真实依赖插入。两组前后世界一致。另在新的 PG17.11 中从公开调用执行权限与回执探针，同一名持合法 READ 的其他操作者在两组首次编译前及既有回执后，都被 VIEW_DENIED；原授权者首次编译分别执行 37 SELECT、11 INSERT、1 UPDATE，各有独立记录，随后使用同一幂等键均得到原回执。两个数据库名不同，原 task/generation 和完整事实、守卫摘要相同。此探针用于核验调用路径，其时间不合入原实验的延迟分布。

同提交、独立 detached worktree、自己的锁定虚拟环境与全新 PG17.11 再次复跑 7 模块 **44 passed，零失败、错误或跳过**，pytest 输出 74.53 秒。从开始至结束 git status 皆为空。所有证据与清单在 frozen-0609015/，其中 manifest.json 包含源码与实测产物的 SHA256、起止版本、逐模块数量、权限探针及采样核对结果。
