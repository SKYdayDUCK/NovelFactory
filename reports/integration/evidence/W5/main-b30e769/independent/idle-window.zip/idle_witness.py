"""Supplemental wall-clock qualification for repeated installed manager timer ticks."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

import psycopg
import pytest
from sqlalchemy.engine import make_url


def snapshot(urls, org, installation):
    with psycopg.connect(urls['aw']) as aw:
        rows = aw.execute(
            """SELECT request_id::text, state, attempts, result FROM aw_resume_requests
               WHERE org_id=%s AND installation_id=%s ORDER BY request_id""",
            (org, installation),
        ).fetchall()
        history = aw.execute(
            "SELECT count(*) FROM aw_change_log WHERE org_id=%s", (org,)
        ).fetchone()[0]
    uri = make_url(urls['nf']).set(drivername='postgresql').render_as_string(hide_password=False)
    with psycopg.connect(uri) as nf:
        tasks = nf.execute("SELECT count(*) FROM nf_tasks").fetchone()[0]
        attempts = nf.execute("SELECT count(*) FROM nf_call_attempts").fetchone()[0]
    return {'wakes':rows, 'org_history_rows': history, 'nf_tasks': tasks, 'nf_attempts': attempts}


@pytest.fixture(autouse=True)
def observe_idle(request, monkeypatch):
    if request.node.name!='test_author_wakeup_recovers_through_real_nf_project_binding':
        yield
        return
    hold=float(os.environ.get('W5_IDLE_TICK_SECONDS','5'));cycles=int(os.environ.get('W5_IDLE_TICK_COUNT','12'))
    assert hold>=5 and cycles>=12
    urls=request.getfixturevalue('dual_databases')
    real_run=subprocess.run
    measurements={}
    def run(cmd,*args,**kwargs):
        original=real_run(cmd,*args,**kwargs)
        if isinstance(cmd,list) and len(cmd)==3 and Path(cmd[0]).name=='aw-manager-run' and original.stdout.strip()=='IDLE' and not measurements:
            path=Path(cmd[2]); cfg=json.loads(path.read_text())
            assert cfg['project']==cfg['delegation']
            marker=Path(cfg['project'][-1]); assert not marker.exists()
            initial=snapshot(urls,cfg['org_id'],cfg['installation_id'])
            assert len(initial['wakes'])==1 and initial['wakes'][0][1:3]==('DONE',1)
            assert initial['nf_tasks']==initial['nf_attempts']==0
            start=time.monotonic();ticks=[]
            for i in range(cycles):
                time.sleep(hold)
                p=real_run(cmd,*args,**kwargs)
                assert p.returncode==0 and p.stdout.strip()=='IDLE' and not marker.exists()
                assert snapshot(urls,cfg['org_id'],cfg['installation_id'])==initial
                ticks.append({'tick':i+1,'elapsed_seconds':round(time.monotonic()-start,3),'state':'IDLE','started_peer':marker.exists()})
            measurements.update(wall_seconds=ticks[-1]['elapsed_seconds'],tick_interval_seconds=hold,extra_ticks=cycles,real_installed_broker_processes=cycles+2,initial=initial,final=snapshot(urls,cfg['org_id'],cfg['installation_id']),ticks=ticks)
        return original
    monkeypatch.setattr(subprocess,'run',run)
    yield
    assert measurements and measurements['wall_seconds']>=hold*cycles
    output=Path(os.environ['W5_IDLE_EVIDENCE'])
    output.write_text(json.dumps(measurements,indent=2,default=str)+'\n')
