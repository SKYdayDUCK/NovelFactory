"""Run exactly one existing notification outage regression using two real native Redis processes."""
import difflib
from hashlib import sha256
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import time

import psycopg
from redis import Redis

repo, run = map(lambda s: Path(s).resolve(), sys.argv[1:])
out = run / "raw"
out.mkdir()
pg = Path(os.environ["PG_BIN"])
nr = Path(os.environ["REDIS_BIN"])
py = repo / 'workshop/.venv/bin/python'
workshop = repo / 'workshop'
sha = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
original = workshop / "tests/test_notifications.py"
source = original.read_text()
key = "test_postgres_mail_during_redis_outage_and_new_worker_processes"
control = [
    ('os.environ.get("AW_REDIS_TEST_CONTAINER")','os.environ.get("NATIVE_REDIS_CONF")'),
    ('    container = os.environ["AW_REDIS_TEST_CONTAINER"]\n',''),
    ('subprocess.run(["docker", "stop", "-t", "2", container], check=True, capture_output=True)',
     'subprocess.run([os.environ["REDIS_BIN"] + "/redis-cli", "-p", os.environ["NATIVE_REDIS_PORT"], "shutdown", "nosave"], check=True, capture_output=True)'),
    ('subprocess.run(["docker", "start", container], check=True, capture_output=True)',
     'subprocess.run([os.environ["REDIS_BIN"] + "/redis-server", os.environ["NATIVE_REDIS_CONF"]], check=True, capture_output=True)'),
]
adapted = source
for old,new in control:
    assert adapted.count(old)==1
    adapted = adapted.replace(old,new)
copy = run / "test_native_outage.py"
copy.write_text(adapted)
(out/'process-control.patch').write_text(''.join(difflib.unified_diff(source.splitlines(keepends=True),adapted.splitlines(keepends=True),fromfile='upstream/test_notifications.py',tofile='native/test_notifications.py')))
def port():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0))
        return s.getsockname()[1]
pport,rport=port(),port()
passfile = run/'admin.pass'
pw,service=secrets.token_hex(20),secrets.token_hex(20)
passfile.write_text(pw+'\n');passfile.chmod(0o600)
data=run/'pgdata'; conf=run/'redis.conf'
conf.write_text(f'port {rport}\nbind 127.0.0.1\nprotected-mode yes\ndir {run}\ndaemonize yes\npidfile {run}/redis.pid\nlogfile {out}/redis.log\nappendonly no\nsave ""\n')
subprocess.run([pg/'initdb','-D',data,'-U','native_admin','--auth-local=reject','--auth-host=scram-sha-256','--pwfile',passfile,'--locale=C','--encoding=UTF8'],stdout=(out/'pg-init.log').open('w'),check=True)
subprocess.run([pg/'pg_ctl','-D',data,'-w','-l',run/'pg.log','-o',f"-p {pport} -h 127.0.0.1 -c unix_socket_directories=''",'start'],stdout=subprocess.DEVNULL,check=True)
try:
    subenv={**os.environ,'PGPASSWORD':pw}
    subprocess.run([pg/'psql','-X','-v','ON_ERROR_STOP=1','-h','127.0.0.1','-p',str(pport),'-U','native_admin','-d','postgres'],input=f"CREATE ROLE w4_mail LOGIN PASSWORD '{service}';\nCREATE DATABASE workshop OWNER w4_mail;\nREVOKE CONNECT ON DATABASE workshop FROM PUBLIC;\n",env=subenv,text=True,stdout=subprocess.DEVNULL,check=True)
    dsn=f'postgresql://w4_mail:{service}@127.0.0.1:{pport}/workshop'
    rurl=f'redis://127.0.0.1:{rport}/0'
    env={**os.environ,'AW_DATABASE_URL':dsn,'AW_REDIS_TEST_URL':rurl,'NATIVE_REDIS_CONF':str(conf),'NATIVE_REDIS_PORT':str(rport)}
    env.pop('AW_REDIS_TEST_CONTAINER',None)
    subprocess.run([py,'-m','alembic','upgrade','head'],cwd=workshop,env=env,stdout=(out/'migration.log').open('w'),stderr=subprocess.STDOUT,check=True)
    subprocess.run([nr/'redis-server',conf],check=True)
    client=Redis.from_url(rurl,decode_responses=True)
    for _ in range(100):
        try:
            if client.ping():break
        except OSError:pass
        time.sleep(0.025)
    def proc():
        info=client.info('server')
        return {k:info[k] for k in ('redis_version','process_id','run_id')}
    original_proc=proc()
    subprocess.run([py,'-m','pytest','-c','pyproject.toml','-o','junit_family=xunit1','-q',str(copy)+'::'+key,'--junitxml='+str(out/'native-outage.xml')],cwd=workshop,env=env,stdout=(out/'pytest.log').open('w'),stderr=subprocess.STDOUT,check=True)
    restarted=proc()
    assert restarted['run_id']!=original_proc['run_id']
    with psycopg.connect(dsn) as conn:
        mail=conn.execute("""SELECT o.event_id::text,o.message_id::text,d.acknowledged_at IS NOT NULL,
            o.last_notified IS NOT NULL, (SELECT count(*) FROM aw_inbox i WHERE i.event_id=o.event_id)
            FROM aw_outbox o JOIN aw_deliveries d USING(org_id,message_id)""").fetchall()
        [(event,message,acknowledged,notified,receipts)]=mail
        assert acknowledged and notified and receipts==1
        version=conn.info.server_version
        head=conn.execute('SELECT version_num FROM aw_alembic_version').fetchone()[0]
    report={'checkout':sha,'checkout_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip(),
            'original_test':'workshop/tests/test_notifications.py::'+key,'source_blob':subprocess.check_output(['git','hash-object',original],text=True).strip(),
            'source_sha256':sha256(source.encode()).hexdigest(),'adapted_sha256':sha256(adapted.encode()).hexdigest(),'postgres_version':version,'schema_revision':head,
            'original_redis':original_proc,'restarted_redis':restarted,'postgres_mail_after_recovery':{'event_id':event,'message_id':message,'acknowledged':acknowledged,'notified':notified,'inbox_rows':receipts},
            'native_execution':{'tests':1,'passed':1,'skipped':0},'docker_sidecar_execution':'skipped on the local host, recorded separately in the original candidate archive',
            'source_changes':'only subprocess stop/start and the corresponding native test fixture selector; application calls, worker processes, SQL, ACK and pending assertions run from the public test',
            'external_provider_calls':0}
    (out/'qualified-result.json').write_text(json.dumps(report,indent=2)+'\n')
finally:
    if (run/'redis.pid').exists():
        subprocess.run([nr/'redis-cli','-p',str(rport),'shutdown','nosave'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    subprocess.run([pg/'pg_ctl','-D',data,'-m','fast','-w','stop'],stdout=subprocess.DEVNULL,check=True)
