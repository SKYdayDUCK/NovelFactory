set -eu
base=/workspace/scratch/eb2b53c756d0
cd "$base/w5-manager-audit/workshop"
export AW_DATABASE_URL="${NF_DATABASE_URL/postgresql+psycopg/postgresql}"
export PYTHONPATH="$PWD/src"
python="$base/qual-w3/aw/workshop/.venv/bin/python"
"$python" -m alembic upgrade head
"$python" -m pytest -q tests/test_manager_lease.py tests/test_manager.py tests/test_resume_upgrade_authority.py --junitxml="$base/w5-manager-evidence/$1.xml"
