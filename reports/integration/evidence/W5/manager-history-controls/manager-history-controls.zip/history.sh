set -eu
base=/workspace/scratch/eb2b53c756d0
cd "$base/w5-history-audit/workshop"
export AW_DATABASE_URL="${NF_DATABASE_URL/postgresql+psycopg/postgresql}"
export PYTHONPATH="$PWD/src"
python="$base/qual-w3/aw/workshop/.venv/bin/python"
"$python" -m alembic upgrade head
"$python" -m pytest -q tests/test_legacy_paid_reviews.py tests/test_manager_history_origins.py tests/test_manager.py -o junit_family=xunit1 --junitxml="$base/w5-manager-evidence/$1.xml"
