#!/usr/bin/env bash
# Run one rehearsal against a new isolated PG17 cluster, using only this bundle and
# the public repository history. PG_BIN must contain PostgreSQL 17 server utilities.
set -eu -o pipefail
here=$(cd "$(dirname "$0")" && pwd)
if [ "${1:-}" = "--cluster" ]; then
    work=$2
    out=$3
    suite=$4
    cd "$work/workshop"
    export AW_DATABASE_URL="${NF_DATABASE_URL/postgresql+psycopg/postgresql}"
    export PYTHONPATH="$work/workshop/src"
    .venv/bin/python -m alembic upgrade head
    if [ "$suite" = worker ]; then
        tests=(tests/test_manager_lease.py tests/test_manager.py tests/test_resume_upgrade_authority.py)
    else
        tests=(tests/test_legacy_paid_reviews.py tests/test_manager_history_origins.py tests/test_manager.py)
        if [ "$suite" = history-six ]; then
            tests+=(-k 'not test_handoff_retains_own_past_events_and_checks_the_current_tenure')
        fi
    fi
    exec .venv/bin/python -m pytest -q -o junit_family=xunit1 "${tests[@]}" --junitxml="$out/result.xml"
fi
arm=${1:?Usage: PG_BIN=/path/to/pg17/bin bash replay.sh ARM /path/to/full/NovelFactory}
source_repo=${2:?Supply a full local Git checkout}
: "${PG_BIN:?Set PG_BIN to PostgreSQL 17 binaries}"
source_repo=$(cd "$source_repo" && pwd)
out=$(mktemp -d "${TMPDIR:-/tmp}/w5-replay.XXXXXXXX")
git clone -q --shared --no-checkout "$source_repo" "$out/repo"
git -C "$out/repo" bundle verify "$here/sources.bundle"
git -C "$out/repo" bundle unbundle "$here/sources.bundle"
worker_base=bfb74f681435b12a385eb54e596c658e64629276
worker_guard=f63d1c3fb19956015d819c2d7b28bc3ee3c5cc2a
worker_final=5605d2418cfdc85f31c4949355980993cfa6a11f
historical_base=c8b9e3c18a6717b8840ad6be54acf398ea0a49a2
historical_final=dab0374d4cb00d069bcae4a420e7d4ef75264e46
suite=worker
case "$arm" in
 original) rev=$worker_base; tests_rev=$worker_guard; count=12; failures=2;;
 fixed) rev=$worker_guard; tests_rev=$worker_guard; count=12; failures=0;;
 lease-control) rev=$worker_guard; tests_rev=$worker_final; count=13; failures=1;;
 lease-final) rev=$worker_final; tests_rev=$worker_final; count=13; failures=0;;
 history-control) rev=$historical_base; suite=history-six; count=6; failures=4;;
 history-fixed) rev=$historical_final; suite=history-six; count=6; failures=0;;
 history-final) rev=$historical_final; suite=history-all; count=7; failures=0;;
 *) echo "Unknown arm: $arm" >&2; exit 2;;
esac
work="$out/repo"
git -C "$work" checkout -q --detach "$rev"
if [ "$suite" = worker ]; then
    git -C "$work" show "$tests_rev:workshop/tests/test_manager_lease.py" > "$work/workshop/tests/test_manager_lease.py"
else
    git -C "$work" show 3fee7f4e88d8174f34cbfac78f3ccd5b98ec245f:workshop/migrations/versions/w005c_signed_routes.py > "$work/workshop/migrations/versions/w005c_signed_routes.py"
    for file in test_manager_history_origins.py test_legacy_paid_reviews.py; do
        git -C "$work" show "$historical_final:workshop/tests/$file" > "$work/workshop/tests/$file"
    done
fi
(cd "$work/workshop" && uv sync --locked --python 3.12 --group dev --extra streams)
rc=0
(cd "$work" && python3 scripts/with_postgres.py --pg-bin "$PG_BIN" --log-dir "$out/pg" -- bash "$here/replay.sh" --cluster "$work" "$out" "$suite") > "$out/run.log" 2>&1 || rc=$?
python3 - "$out/result.xml" "$count" "$failures" "$rc" <<'PY'
import sys
from xml.etree import ElementTree
path, tests, failures, rc = sys.argv[1:]
s = ElementTree.parse(path).getroot().find('testsuite')
actual = tuple(int(s.attrib[k]) for k in ('tests', 'failures', 'errors', 'skipped'))
assert actual == (int(tests), int(failures), 0, 0), actual
assert int(rc) == (1 if int(failures) else 0), rc
print('Confirmed', actual, 'tests, failures, errors, skipped')
PY
echo "Evidence: $out"
