#!/usr/bin/env bash
set -eu -o pipefail
checkout=$(cd "$1" && pwd)
output=$(mkdir -p "$2" && cd "$2" && pwd)
expected=$3
test "$(git -C "$checkout" rev-parse HEAD)" = "$expected"
test -z "$(git -C "$checkout" status --porcelain --untracked-files=no)"
git -C "$checkout" show -s --format='%H %T %P' HEAD > "$output/revision.txt"
cd "$checkout/workshop"
export AW_DATABASE_URL="${NF_DATABASE_URL/postgresql+psycopg/postgresql}"
export AW_W4_LEGACY_REVIEW_EVIDENCE="$output/legacy.json"
export AW_W4_ROUTING_UPGRADE_EVIDENCE_DIR="$output/upgrade-receipts"
mkdir -p "$AW_W4_ROUTING_UPGRADE_EVIDENCE_DIR"
.venv/bin/python -I -c 'import agent_workshop,sys; print(sys.version); print(agent_workshop.__file__)' > "$output/runtime.txt"
.venv/bin/python -m alembic upgrade head
.venv/bin/python -m pytest -q tests/test_manager_lease.py tests/test_manager.py tests/test_resume_upgrade_authority.py -o junit_family=xunit1 --junitxml="$output/worker.xml"
.venv/bin/python -m pytest -q tests/test_manager_history_origins.py tests/test_legacy_paid_reviews.py tests/test_manager.py -o junit_family=xunit1 --junitxml="$output/history.xml"
git -C "$checkout" status --porcelain --untracked-files=no > "$output/final-status.txt"
test ! -s "$output/final-status.txt"
