"""Verify selected bytes and optionally compare with original GitHub ZIPs."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(condition,message):
    if not condition:
        raise SystemExit(message)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('selected',type=Path)
    parser.add_argument('--sources',type=Path, help='Recursively index original GitHub ZIP archives by SHA-256.')
    args=parser.parse_args()
    originals={}
    if args.sources:
        for p in args.sources.rglob('*.zip'):
            originals[sha(p.read_bytes())]=p
    with zipfile.ZipFile(args.selected) as z:
        m=json.loads(z.read('manifest.json'))
        sources={s['id']:s for s in m['sources']}
        by_artifact={}
        names=z.namelist()
        expected={'manifest.json','README.md','verify.py'}|{f['path'] for f in m['files']}
        check(len(names)==len(set(names)) and set(names)==expected,'archive index mismatch')
        try:
            if args.sources:
                for sid,s in sources.items():
                    check(s['sha256'] in originals,'missing source artifact '+str(sid))
                    by_artifact[sid]=zipfile.ZipFile(originals[s['sha256']])
            for f in m['files']:
                data=z.read(f['path'])
                check(len(data)==f['bytes'] and sha(data)==f['sha256'],f['path'])
                if args.sources:
                    raw=by_artifact[f['source_artifact_id']].read(f['source_member'])
                    start,end=f['byte_range']
                    check(sha(raw)==f['source_member_sha256'] and raw[start:end]==data,f['path'])
                    if f['json_field'] is None:
                        check((start,end)==(0,len(raw)),f['path'])
                    else:
                        check(json.loads(raw)[f['json_field']]==json.loads(data),f['path'])
        finally:
            for src in by_artifact.values():
                src.close()
    print('verified',len(m['files']),'items;',len(sources),'source artifacts;', 'source-byte comparison complete' if args.sources else 'payload digests checked')

if __name__=='__main__':
    main()

