#!/usr/bin/env bash
set -euo pipefail
root=$(realpath "$1")
out=$(realpath "$2")
shift 2
cd "$root/workshop"
"$PG_BIN/psql" -X -v ON_ERROR_STOP=1 -c 'CREATE ROLE workshop_check LOGIN'
"$PG_BIN/createdb" -O workshop_check aw_route_checks
export AW_DATABASE_URL="postgresql://workshop_check@$PGHOST:$PGPORT/aw_route_checks"
if test "${BOOTSTRAP_BOTH_HEADS:-0}" = 1; then .venv/bin/python -m alembic upgrade heads; else .venv/bin/aw-migrate upgrade; fi
.venv/bin/python -m pytest "$@" --junitxml="$out/junit.xml"
