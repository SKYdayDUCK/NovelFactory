import os
from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def early_settlement_lookup(request, monkeypatch):
    scene = request.module
    if request.node.callspec.params["preset"] != "Long-form":
        return
    initialize = scene.Mail.__init__

    def install(mail, *args, **kwargs):
        initialize(mail, *args, **kwargs)
        def set_due():
            if not any(message["kind"] == "REPORT" for message in mail.history):
                return
            with scene.connect(mail.dsn) as conn:
                row = conn.execute(
                    """UPDATE aw_delegations SET next_check=clock_timestamp()+interval '2 seconds'
                       WHERE installation_id=%s AND org_id=%s AND state='BOUND'
                       RETURNING operation_id, extract(epoch FROM next_check-clock_timestamp()) AS seconds""",
                    (mail.installation, mail.org),
                ).fetchall()
                assert len(row) == 1 and 1.5 < row[0]["seconds"] <= 2
                Path(os.environ["AW_ACCEPTANCE_OUTPUT"], "early-poll.txt").write_text(
                    "test-only scheduling of existing BOUND operation after real manager report\n"
                    + f'{row[0]["operation_id"]} {row[0]["seconds"]} seconds before eligibility\n'
                )
        mail.stack.callback(set_due)
    monkeypatch.setattr(scene.Mail, "__init__", install)
