#!/usr/bin/env bash
set -euo pipefail
base=$(realpath "$1")
sha=$2
target=$3
interpreter=$4
git -C "$base" worktree add --detach "$target" "$sha"
uv sync --project "$target" --locked --offline --python "$interpreter" --group dev >/dev/null
uv sync --project "$target/workshop" --locked --offline --python "$interpreter" --group dev --extra streams >/dev/null
