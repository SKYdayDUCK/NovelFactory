"""Summarize W6 raw receipts using their original fixed archive contract."""
import hashlib
import json
import sys
from pathlib import Path
from xml.etree import ElementTree

out = Path(sys.argv[1]).resolve()
result = {"head": sys.argv[2], "messages": [], "delegations": []}
for directory, key in ((out / "message", "messages"), (out / "delegation", "delegations")):
    manifest = json.loads((directory / "source.json").read_text())
    assert manifest["head_sha"] == result["head"]
    samples = sorted(directory.glob(f"{key}-*.json"))
    expected = 3 if key == "messages" else 9
    assert len(samples) == expected, f"{directory} contains {len(samples)}/{expected} expected receipts"
    for sample in samples:
        data = json.loads(sample.read_text())
        if key == "messages":
            assert data["started_workshop_sha"] == result["head"]
            assert data["message_gate"] == "PASS"
            row = {k: data[k] for k in ("employees", "unique_completed_exchanges", "receipt_counts",
                                         "latency", "notification_loss_and_restart", "message_gate")}
        else:
            row = {k: data[k] for k in ("registered_members", "policy", "accepted", "unique_tasks",
                        "settled", "held", "provider_requests", "synthetic_reported_tokens",
                        "observed_peak_model_calls", "model_calls_while_idle", "elapsed_s", "latency_ms")}
        row["raw"] = sample.relative_to(out).as_posix()
        row["sha256"] = hashlib.sha256(sample.read_bytes()).hexdigest()
        result[key].append(row)
junit = ElementTree.parse(out / "delegation" / "delegation-junit.xml").find("testsuite")
assert junit is not None and junit.get("tests") == "9"
assert all(junit.get(k) == "0" for k in ("errors", "failures", "skipped"))
result["delegation_junit"] = dict(junit.attrib)
(out / "summary.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
