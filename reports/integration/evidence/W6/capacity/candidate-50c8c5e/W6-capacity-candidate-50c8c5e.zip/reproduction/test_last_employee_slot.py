"""Evidence probe for two legitimate hires competing for one available roster slot."""
import json
import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
from uuid import uuid4

import pytest
from agent_workshop.admin import enroll
from agent_workshop.auth import Denied, connect
from agent_workshop.organization import bootstrap
from agent_workshop.presets import configure_limits
from agent_workshop.server import dispatch


def test_concurrent_last_employee_slot():
    dsn = os.environ["AW_DATABASE_URL"]
    org, inst = uuid4().hex, str(uuid4())
    with connect(dsn) as conn:
        conn.execute("INSERT INTO aw_installations VALUES (%s,%s,true)", (inst, str(uuid4())))
        bootstrap(conn, org, "Minimal", installation_id=inst)
        token = enroll(conn, inst, org, "manager", 1, 1)
        roster_before = conn.execute(
            "SELECT count(*) AS n FROM aw_employees WHERE org_id=%s AND status='ACTIVE'", (org,)
        ).fetchone()["n"]
        configure_limits(conn, org, roster_before + 1, 2, {"character_actor": ["actors"]})

    barrier = Barrier(2)
    manager = {"database_url": dsn, "token": token}

    def hire(name, rev):
        return dispatch(manager, "aw_hire", {
            "operation_id": name, "employee_id": name, "supervisor_id": "volume", "team_id": "actors",
            "role_id": "character_actor", "expected_revision": rev,
        })

    def compete(name):
        barrier.wait(timeout=10)
        try:
            return name, hire(name, 1)
        except Denied as exc:
            return name, str(exc)

    with ThreadPoolExecutor(max_workers=2) as pool:
        outcomes = dict(pool.map(compete, ("candidate-one", "candidate-two")))
    winner, = [name for name, value in outcomes.items() if isinstance(value, dict)]
    loser, = [name for name, value in outcomes.items() if value == "STALE_ORG_REVISION"]
    assert hire(winner, 1) == outcomes[winner]
    with pytest.raises(Denied, match="^ROSTER_LIMIT_EXCEEDED$"):
        hire(loser, 2)
    with connect(dsn) as conn:
        roster_after = conn.execute(
            "SELECT count(*) AS n FROM aw_employees WHERE org_id=%s AND status='ACTIVE'", (org,)
        ).fetchone()["n"]
        receipts = conn.execute(
            "SELECT count(*) AS n FROM aw_org_operations WHERE org_id=%s", (org,)
        ).fetchone()["n"]
    assert roster_after == roster_before + 1
    assert receipts == 1
    Path(os.environ["AW_ROSTER_RACE_EVIDENCE"]).write_text(
        json.dumps({"workers": 2, "roster_before": roster_before, "active_limit": roster_before + 1,
                    "roster_after": roster_after, "receipt_count": receipts, "outcomes": outcomes,
                    "replay": "SAME_RECEIPT", "latest_revision_retry": "ROSTER_LIMIT_EXCEEDED"},
                   indent=2) + "\n"
    )
