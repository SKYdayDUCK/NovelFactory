#!/usr/bin/env bash
set -euo pipefail
scratch=$(realpath "$1")
sha=$2
stage=$3
here=$(dirname "$(realpath "$0")")
out="$here/$stage-${sha:0:7}"
mkdir -p "$out"/{delegation,message,controls}
if ! git -C "$scratch/NovelFactory" cat-file -e "$sha^{commit}" 2>/dev/null; then
    git -C "$scratch/NovelFactory" fetch --no-write-fetch-head --no-tags origin "$sha"
fi
bash "$here/prepare-checkout.sh" "$scratch/NovelFactory" "$sha" "$out/repo" "$scratch/NovelFactory/.venv/bin/python" >"$out/setup.log" 2>&1
pids=()
for phase in delegation message controls; do
    TMPDIR="$here/runtmp" bash "$here/run-at-sha.sh" "$out/repo" "$out/$phase" "$sha" "$phase" \
        "$scratch/qualification-w2/pg17/usr/lib/postgresql/17/bin" "$scratch/qualification-w2/redis-build/redis-8.0.2/src" >"$out/$phase/command.log" 2>&1 &
    pids+=("$!")
done
status=0
for pid in "${pids[@]}"; do wait "$pid" || status=1; done
if test "$status" = 0; then
    "$out/repo/.venv/bin/python" "$here/summarize.py" "$out" "$sha"
fi
exit "$status"
