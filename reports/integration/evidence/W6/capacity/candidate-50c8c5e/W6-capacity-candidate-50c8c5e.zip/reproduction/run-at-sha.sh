#!/usr/bin/env bash
set -euo pipefail
root=$(realpath "$1")
out=$(realpath "$2")
expected_sha=$3
phase=$4
pgbin=$(realpath "$5")
redisbin=$(realpath "$6")
here=$(dirname "$(realpath "$0")")
test "$(git -C "$root" rev-parse HEAD)" = "$expected_sha"
test -z "$(git -C "$root" status --porcelain --untracked-files=no)"
"$root/.venv/bin/python" - "$root" "$out" "$phase" "$expected_sha" "$pgbin" "$redisbin" <<'PY'
from pathlib import Path
import hashlib, json, os, platform, subprocess, sys
from datetime import UTC, datetime
root,out,phase,sha,pg,redis=sys.argv[1:]
paths=['workshop/benchmarks/message_capacity.py','workshop/benchmarks/delegation_capacity.py','workshop/benchmarks/capacity-contract.json','workshop/benchmarks/delegation-contract.json','workshop/benchmarks/admission-comparison.json','workshop/uv.lock','uv.lock','workshop/integration/conftest.py','workshop/src/agent_workshop/server.py','workshop/src/agent_workshop/reconcile.py','src/novel_factory/application/supervisor.py','src/novel_factory/application/delegation.py']
manifest={'head_sha':sha,'phase':phase,'started_utc':datetime.now(UTC).isoformat(),'cpu_count':os.cpu_count(),'kernel':platform.platform(),'python':platform.python_version(),'postmaster':subprocess.check_output([pg+'/postgres','--version'],text=True).strip(),'redis_server':subprocess.check_output([redis+'/redis-server','--version'],text=True).strip(),'file_sha256':{p: hashlib.sha256((Path(root)/p).read_bytes()).hexdigest() for p in paths}}
for name in ('cpu.max', 'memory.max', 'cpuset.cpus.effective'):
    limit = Path('/sys/fs/cgroup') / name
    if limit.is_file():
        manifest[name]=limit.read_text().strip()
(Path(out)/'source.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
PY
case "$phase" in
  message)
    child=( bash "$here/run-message.sh" "$root" "$out" "$redisbin" ) ;;
  delegation)
    child=( bash "$here/run-delegation.sh" "$root" "$out" aw "fixed-1 or fixed-2 or adaptive-2" ) ;;
  controls)
    export AW_ROUTE_MATRIX_EVIDENCE="$out/routing.json"
    export AW_ROSTER_RACE_EVIDENCE="$out/last-employee-slot.json"
    child=( bash "$here/preset-role-check.sh" "$root" "$out" -q --tb=line tests/test_preset_fences.py tests/test_routing_matrix.py tests/test_messaging.py tests/test_w2_stdio.py tests/test_manager_lease.py "$here/test_last_employee_slot.py" ) ;;
  smoke)
    child=( bash "$here/run-delegation.sh" "$root" "$out" aw "fixed-1-10" ) ;;
  *) exit 2 ;;
esac
exec "$root/.venv/bin/python" "$root/scripts/with_postgres.py" --pg-bin "$pgbin" --log-dir "$out/pg" -- "${child[@]}"
