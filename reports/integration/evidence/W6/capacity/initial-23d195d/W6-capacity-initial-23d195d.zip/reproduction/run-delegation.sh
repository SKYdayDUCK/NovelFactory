#!/usr/bin/env bash
set -euo pipefail
root=$(realpath "$1")
out=$(realpath "$2")
phase=$3
selector=$4
if test "$phase" = aw; then
    export AW_DUAL_TEST_ADMIN_URL="postgresql://$PGUSER@$PGHOST:$PGPORT/postgres"
    exec "$root/.venv/bin/python" "$root/scripts/with_postgres.py" --pg-bin "$PG_BIN" --log-dir "$out/pg-nf" -- bash "$0" "$root" "$out" nf "$selector"
fi
export AW_DUAL_TEST_NF_ADMIN_URL="postgresql://$PGUSER@$PGHOST:$PGPORT/postgres"
export AW_NF_SOURCE="$root"
export PYTHONPATH="$root/workshop/src:$root/src:$root"
export AW_BENCH_RESULTS="$out"
export AW_ACCEPTANCE_OUTPUT="$out"
export PATH="$root/.venv/bin:$PG_BIN:$PATH"
cd "$root/workshop"
"$root/.venv/bin/python" -m pytest -q benchmarks/delegation_capacity.py -k "$selector" --junitxml="$out/delegation-junit.xml"
