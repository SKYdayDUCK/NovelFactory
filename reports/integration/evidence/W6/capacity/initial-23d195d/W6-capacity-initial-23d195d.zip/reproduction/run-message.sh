#!/usr/bin/env bash
set -eu
root=$(realpath "$1")
out=$(realpath "$2")
port=$("$root/.venv/bin/python" -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1",0)); print(s.getsockname()[1])')
redisdir=$(realpath "$3")
"$redisdir/redis-server" --bind 127.0.0.1 --port "$port" --save "" --appendonly no --dir "$out" --logfile "$out/redis.log" >"$out/redis-stdout.log" 2>&1 &
redispid=$!
trap 'kill "$redispid" || true; wait "$redispid" || true' EXIT
for step in {1..30}; do
    if "$redisdir/redis-cli" -h 127.0.0.1 -p "$port" ping | rg -q PONG; then break; fi
    sleep 0.2
done
export AW_REDIS_URL="redis://127.0.0.1:$port/0"
cd "$root/workshop"
"$PG_BIN/psql" -X -v ON_ERROR_STOP=1 -c "CREATE ROLE workshop_bench LOGIN"
status=0
for n in 10 50 200; do
    db="aw_benchmark_$n"
    "$PG_BIN/createdb" -O workshop_bench "$db"
    export AW_DATABASE_URL="postgresql://workshop_bench@$PGHOST:$PGPORT/$db"
    if test "${BOOTSTRAP_BOTH_HEADS:-0}" = 1; then
        .venv/bin/python -m alembic upgrade heads >"$out/migrate-$n.log" 2>&1
    else
        .venv/bin/aw-migrate upgrade >"$out/migrate-$n.log" 2>&1
    fi
    if ! .venv/bin/python benchmarks/message_capacity.py --employees "$n" --output "$out/messages-$n.json" >"$out/messages-$n.log" 2>&1; then status=1; fi
    "$root/.venv/bin/python" - "$out/messages-$n.json" <<'PY'
from collections import Counter
import json,sys
from pathlib import Path
p=Path(sys.argv[1])
if p.exists():
    d=json.loads(p.read_text())
    print(d['employees'], d['message_gate'], d['unique_completed_exchanges'], d['scheduled_messages'], Counter(r.get('code','?') for r in d['records'] if not r['completed']), flush=True)
PY
done
exit "$status"
