"""Restart an already qualified, stopped, disposable PG17 instance; compare all eight populated W5/W6 database histories."""
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

import psycopg

scratch = Path(sys.argv[1]).resolve()
repo = Path(sys.argv[2]).resolve()
out = Path(sys.argv[3]).resolve()
out.mkdir(exist_ok=True)
data = scratch / "pg"
assert data.is_dir() and not (data / "postmaster.pid").exists()
sys.path.insert(0, str(repo / "workshop/acceptance"))
from test_w2_historical_upgrades import columns, snapshot

pgbin = Path(os.environ["PG_BIN"])
with socket.socket() as sock:
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
env = {**os.environ, "PGPASSWORD": (scratch / "pass").read_text().strip()}
env.pop("PGHOST", None)
def ctl(action):
    args=[pgbin/"pg_ctl", "-D", data, "-w"]
    if action=="start":
        args.extend(["-l",scratch/"restart-postgres.log", "-o", f"-h 127.0.0.1 -p {port} -c unix_socket_directories=''"])
    else:
        args.extend(["-m","fast"])
    subprocess.run([*args,action],env=env,check=True,stdout=subprocess.DEVNULL)

def evidence():
    all_db={}
    meta={}
    for name in ("w6_from_w5c","w6_from_w006","w6_from_w007","w6_from_w008","w6_from_w008a","w6_from_rehearsal_early","w6_from_rehearsal_late","w6_from_w009"):
        with psycopg.connect(host="127.0.0.1",port=port,user="w4_admin",dbname=name,password=env["PGPASSWORD"]) as c:
            meta={"system_identifier":c.execute("SELECT system_identifier::text FROM pg_control_system()").fetchone()[0],
                  "started":c.execute("SELECT pg_postmaster_start_time()::text").fetchone()[0],"version":c.info.server_version}
            c.execute("SET ROLE aw_service")
            assert c.execute("SELECT current_user").fetchone()==("aw_service",)
            assert c.execute("SELECT rolsuper FROM pg_roles WHERE rolname=current_user").fetchone()==(False,)
            current=c.execute("SELECT version_num FROM aw_alembic_version").fetchall()
            assert current==[("w010",)]
            rows=snapshot(c,columns(c))
            acl=c.execute("SELECT oid,relacl::text,has_table_privilege(oid,'DELETE') FROM pg_class WHERE oid='aw_remote_receipts'::regclass").fetchone()
            assert not acl[2]
            settlement=c.execute("SELECT status,settled_amount::text FROM aw_budget_holds").fetchone()
            assert settlement[0]=="SETTLED" and float(settlement[1])==0.2
            proof=c.execute("SELECT ledger FROM aw_recovery_proofs").fetchone()[0]
            assert proof["attempts"][0]["actual_tokens"]==9 and proof["attempts"][0]["state"]=="SUCCEEDED"
            assert c.execute("SELECT frozen FROM aw_recovery_fences").fetchall()==[(False,)]
            modes=c.execute("""SELECT c.relname,t.tgname,t.tgenabled FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid
                 WHERE c.relnamespace=current_schema()::regnamespace AND NOT t.tgisinternal ORDER BY 1,2""").fetchall()
            all_db[name]={"tables":rows,"grant_and_oid":acl,"hold":settlement,"proof":proof,"frozen":False,"trigger_modes":modes,"alembic":current}
    return meta,all_db

ctl("start")
try:
    first,before=evidence()
finally:
    ctl("stop")
assert not (data/"postmaster.pid").exists()
ctl("start")
try:
    second,after=evidence()
finally:
    ctl("stop")
assert before==after
assert first["system_identifier"]==second["system_identifier"] and first["started"]!=second["started"]
result={"source":subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip(),
        "tree":subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=repo,text=True).strip(),
        "before_postmaster":first,"after_postmaster":second,"old_pid_file_absent_between_instances":True,
        "same_tables_acl_triggers_proofs_and_budget":True,"inspection_role":"aw_service (non-superuser); bootstrap identity starts and stops its own test cluster only",
        "before_and_after_database_sha256":hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),
        "databases":after}
(out/"physical-restart.json").write_text(json.dumps(result,indent=2)+"\n")
print("Verified",len(after),"databases across",first["started"],second["started"])
