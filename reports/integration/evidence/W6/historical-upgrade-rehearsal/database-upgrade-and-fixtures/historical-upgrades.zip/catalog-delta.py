import hashlib,json,os,socket,subprocess,sys
from pathlib import Path
import psycopg
repo=Path(sys.argv[1]).resolve();s=Path(sys.argv[2]).resolve(); pg=Path(os.environ['PG_BIN'])
sys.path.insert(0,str(repo/'workshop/tests'))
from test_w4_routing_upgrade import catalog
with socket.socket() as sock:
 sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
subprocess.run([pg/'pg_ctl','-D',s/'pg','-w','-l',s/'delta-server.log','-o',f"-p {port} -h 127.0.0.1 -c unix_socket_directories=''","start"],check=True,stdout=subprocess.DEVNULL)
try:
 def read(name):
  with psycopg.connect(host='127.0.0.1',port=port,user='w4_admin',password=(s/'pass').read_text().strip(),dbname=name) as c:
   return dict(((a,b),v) for a,b,v in catalog(c))
 fresh=read('workshop');early=read('w6_from_rehearsal_early')
 result={'missing':list(sorted(fresh.keys()-early.keys())),'extra':list(sorted(early.keys()-fresh.keys())),'changed':[[k,fresh[k],early[k]] for k in sorted(fresh.keys()&early.keys()) if fresh[k]!=early[k]]}
 (s/'early-catalog-difference.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
finally:subprocess.run([pg/'pg_ctl','-D',s/'pg','-m','fast','-w','stop'],check=True,stdout=subprocess.DEVNULL)
