#!/bin/bash
set -eu
base=/workspace/scratch/eb2b53c756d0
cd "$base/w3-recovery-control/workshop"
export AW_DATABASE_URL="${NF_DATABASE_URL/postgresql+psycopg/postgresql}"
export PYTHONPATH="$PWD/src"
python="$base/qual-w3/aw/workshop/.venv/bin/python"
"$python" -m alembic upgrade head
"$python" -m pytest -q tests/test_delegation_recovery_receipt.py tests/test_delegation.py tests/test_delegation_upgrade_authority.py --junitxml="$base/w3-authority-evidence/$1.xml"
