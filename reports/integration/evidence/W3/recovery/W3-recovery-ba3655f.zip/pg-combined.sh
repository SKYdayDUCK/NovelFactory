#!/bin/bash
set -eu
base=/workspace/scratch/eb2b53c756d0
cd "$base/w3-recovery-combination/workshop"
export AW_DATABASE_URL="${NF_DATABASE_URL/postgresql+psycopg/postgresql}"
export PYTHONPATH="$PWD/src"
python="$base/qual-w3/aw/workshop/.venv/bin/python"
"$python" -m alembic upgrade head
"$python" -m pytest -q tests/test_delegation_recovery_receipt.py tests/test_delegation.py tests/test_delegation_upgrade_authority.py --junitxml="$base/w3-authority-evidence/$1.xml"
createdb w3_archived
createdb w3a_archived
export AW_W3_FROM_W3_DATABASE_URL="${AW_DATABASE_URL%/*}/w3_archived"
export AW_W3_FROM_W3A_DATABASE_URL="${AW_DATABASE_URL%/*}/w3a_archived"
"$python" -m pytest -q -c pyproject.toml acceptance/test_w3_historical_upgrades.py -o junit_family=xunit1 --junitxml="$base/w3-authority-evidence/$1-historical.xml"
export AW_NF_SOURCE="$base/w3-recovery-combination"
export AW_DUAL_TEST_ADMIN_URL="${AW_DATABASE_URL%/*}/postgres"
export AW_PAIRED_RESTORE_EVIDENCE="$base/w3-authority-evidence/$1-paired.json"
export PYTHONPATH="$AW_NF_SOURCE/workshop/src:$AW_NF_SOURCE/src:$AW_NF_SOURCE"
cd "$AW_NF_SOURCE"
"$base/qual-bridge/upgrade/.venv/bin/python" -m pytest -q -c pyproject.toml workshop/integration/test_dual_stdio.py workshop/integration/test_paired_restore.py -o junit_family=xunit1 --junitxml="$base/w3-authority-evidence/$1-dual-pitr.xml"
