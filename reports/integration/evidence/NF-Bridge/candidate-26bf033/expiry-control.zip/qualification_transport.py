"""Fail closed before transport I/O if the model authorization reached a denied boundary."""
import pytest

@pytest.fixture(autouse=True)
def no_model_transport(monkeypatch):
    from novel_factory.infrastructure.model_gateway import OpenAICompatibleAdapter

    def prevent_transport(_self, _request):
        pytest.fail("Model dispatch reached the synthetic adapter after expiry. Transport stopped before I/O.")

    monkeypatch.setattr(OpenAICompatibleAdapter, "generate", prevent_transport)
