"""Scope-limited SQL counts. No bind values, statements or task content are retained."""
from collections import Counter
import json
import os
from pathlib import Path
import pytest
from sqlalchemy import event
from sqlalchemy.engine import Engine

counts = {}

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    c = Counter(sql_statements=0, delegation_statements=0, spending_guard_sql=0)
    def observe(conn, cursor, statement, params, ctx, many):
        c["sql_statements"] += 1
        query = statement.lower()
        c["delegation_statements"] += int("nf_delegation_" in query)
        c["spending_guard_sql"] += int("for share of i, w, g" in query)
    event.listen(Engine, "before_cursor_execute", observe)
    try:
        yield
    finally:
        event.remove(Engine, "before_cursor_execute", observe)
        counts[item.nodeid] = dict(c)

def pytest_sessionfinish(session, exitstatus):
    Path(os.environ["BRIDGE_SQL_COUNTS"]).write_text(json.dumps(counts, indent=2) + "\n")
