from test_workshop_delegation import site
from tests.conftest import kernel_env
from novel_factory.application.delegation import Delegations, installation_ledger, reconcile_restored_installation
from novel_factory.infrastructure.recovery import fence_recovered_tasks

def test_recovery_ledger_excludes_public_only_progress_and_can_unfence(site, monkeypatch):
    bridge, submit, get, _, supervisor, owner, requests, _ = site
    kernel = bridge.kernel
    bridge.call("nf_delegation_submit", submit)
    supervisor.admit_model(owner, get["work_id"], get["branch_id"])
    public = bridge.call("nf_delegation_get", get)
    assert public["accounting_state"] == "UNKNOWN"
    assert "result_ref" in public and "wait_reason" in public
    fence_recovered_tasks(kernel.db.engine, kernel.objects)

    def public_only(*args):
        raise AssertionError("Recovery invoked the public-only progress computation")
    monkeypatch.setattr(Delegations, "_wait_reason", staticmethod(public_only))
    ledger = installation_ledger(kernel, owner, bridge.installation_id)
    item = ledger[get["operation_id"]]
    assert set(item) == {"task_id", "receipt_ref", "generation", "task_state", "accounting_state", "attempts"}
    assert item["receipt_ref"] == public["receipt_ref"] and item["attempts"] == public["attempts"]
    assert item["accounting_state"] == "UNKNOWN" and len(requests) == 1
    reconcile_restored_installation(kernel, owner, bridge.installation_id, ledger)
    assert len(requests) == 1
