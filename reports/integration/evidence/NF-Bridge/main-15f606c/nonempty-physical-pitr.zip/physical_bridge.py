"""Additional Bridge witness on the pinned product's unmodified P4 physical WAL drill and NF services."""
import asyncio
from contextlib import ExitStack
from decimal import Decimal
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from uuid import uuid4

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from sqlalchemy import text

from novel_factory.application.agent_gateway import AgentGateway
from novel_factory.application.supervisor import RuntimeSupervisor
from novel_factory.domain.errors import DomainError


def check(test, message):
    if not test:
        raise RuntimeError(message)


def refs(kernel):
    with kernel.db.engine.connect() as conn:
        return {table: conn.scalar(text(f"SELECT count(*) FROM nf_delegation_{table}"))
                for table in ("installations", "slots", "receipts")}


def budget_and_call(kernel, task):
    with kernel.db.uow(write=False) as repo:
        [call] = repo.many("call_attempts", {"task_id": task})
        budget = repo.one("budgets", {"budget_id": call["budget_id"]})
        return {"attempt_id": str(call["attempt_id"]), "state": call["state"],
                "reserved_amount": str(call["reserved_amount"]), "reserved_tokens": call["reserved_tokens"],
                "actual_amount": str(call["actual_amount"]) if call["actual_amount"] is not None else None,
                "actual_tokens": call["actual_tokens"], "budget_id": str(call["budget_id"]),
                "budget_reserved": str(budget["reserved_amount"]), "budget_spent": str(budget["spent_amount"])}


async def invoke(binding, method, params, expected_error=None):
    server = StdioServerParameters(command=sys.executable,
        args=["-m", "novel_factory.interfaces.delegation_stdio", "--binding", str(binding)])
    async with stdio_client(server) as streams, ClientSession(*streams) as session:
        hello = await session.initialize()
        check(hello.serverInfo.name == "NovelFactory.Delegation", "Unexpected server identity")
        check({tool.name for tool in (await session.list_tools()).tools}
              == {"nf_delegation_submit", "nf_delegation_get"}, "Unexpected capability")
        response = await session.call_tool(method, params)
        if expected_error:
            check(response.isError and response.structuredContent == {"error": {"code": expected_error}},
                  "Unexpected scoped denial")
        else:
            check(not response.isError, "Dedicated stdio request failed")
        return response.structuredContent


def seed(stack, kernel, url):
    from test_workshop_delegation import site
    private = Path(stack.enter_context(TemporaryDirectory(prefix="nf-bridge-private-")))
    scenario = site.__wrapped__({"kernel": kernel, "url": url}, private)
    stack.callback(scenario.close)
    runtime, submit, get, binding, supervisor, owner, requests, _ = next(scenario)
    receipt = asyncio.run(invoke(binding, "nf_delegation_submit", submit))
    supervisor.admit_model(owner, get["work_id"], get["branch_id"])
    witness = asyncio.run(invoke(binding, "nf_delegation_get", get))
    accounting = budget_and_call(kernel, receipt["task_id"])
    check(witness["accounting_state"] == "UNKNOWN" and len(requests) == 1, "Synthetic dispatch not retained")
    check(len(witness["attempts"]) == 1 and witness["attempts"][0]["state"] == "UNKNOWN"
          and witness["attempts"][0]["attempt_id"] == accounting["attempt_id"], "Unexpected attempt identity")
    check(accounting["actual_amount"] is None and accounting["actual_tokens"] is None and
          Decimal(accounting["budget_reserved"]) == Decimal("0.10") and accounting["reserved_tokens"] == 100000,
          "Budget witness is incomplete")
    check(refs(kernel) == {"installations":1,"slots":1,"receipts":1}, "Bridge rows not committed")
    return dict(private=private, source_binding=binding, submit=submit, get=get, supervisor=supervisor,
                owner=owner, requests=requests, witness=witness, accounting=accounting, runtime=runtime)


def later_settlement(kernel, case):
    a = case["accounting"]
    kernel.tasks.settle_call(a["attempt_id"], state="SUCCEEDED", actual_amount="0.02", actual_tokens=18,
                             provider_receipt="synthetic-post-target-invoice")
    after = budget_and_call(kernel, case["witness"]["task_id"])
    check(after["state"] == "SUCCEEDED" and after["actual_tokens"] == 18 and
          Decimal(after["budget_reserved"]) == 0 and Decimal(after["budget_spent"]) == Decimal(".02"),
          "Missing deliberately later committed settlement")
    return after


def restored_witness(kernel, url, case):
    path = case["private"] / "restored.json"
    cfg = json.loads(case["source_binding"].read_text())
    cfg.update(database_url=url, object_root=str(kernel.objects.root))
    with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "w") as f:
        json.dump(cfg, f)
    submit, get, old, want = case["submit"], case["get"], case["witness"], case["accounting"]
    current = asyncio.run(invoke(path, "nf_delegation_get", get))
    replay = asyncio.run(invoke(path, "nf_delegation_submit", submit))
    check(current == replay, "Same operation rebind after restoration")
    for field in ("receipt_ref", "task_id", "world_ref", "attempts", "accounting_state", "actual_amount", "actual_tokens"):
        check(current[field] == old[field], "Lost target data: " + field)
    check(current["task_state"] == "PAUSED" and current["generation"] == old["generation"]+1,
          "Recovered task generation not fenced")
    check(budget_and_call(kernel,current["task_id"]) == want, "Lost UNKNOWN reservation")
    denied = asyncio.run(invoke(path,"nf_delegation_submit",dict(submit,operation_id=str(uuid4())),
                                "DELEGATION_RECOVERY_FENCED"))
    for fn, args, kw in [
        (kernel.tasks.mark_call_sent, (want["attempt_id"],), {"worker_id":"pre-crash-worker"}),
        (kernel.tasks.reserve_call, (current["task_id"],current["generation"],"pre-crash-worker"),
         {"budget_id":want["budget_id"],"amount":"0.1","call_key":"recovery-retry",
          "request_hash":"a"*64,"token_amount":100000}),
    ]:
        try:
            fn(*args, **kw)
        except DomainError as exc:
            check(exc.code=="DELEGATION_RECOVERY_FENCED","Wrong inference fence")
        else:
            raise RuntimeError("Recovery permitted a new dispatch or budget hold")
    supervisor = RuntimeSupervisor(kernel,AgentGateway(kernel,case["supervisor"].gateway.adapters))
    outcome = supervisor.admit_model(case["owner"],get["work_id"],get["branch_id"])
    check(outcome["status"]=="IDLE" and len(case["requests"])==1, "Recovered job dispatched a second provider call")
    check(refs(kernel)=={"installations":1,"slots":1,"receipts":1} and
          budget_and_call(kernel,current["task_id"])==want, "Recovery retry changed Bridge rows or money")
    return {"source_stdio":old,"restored_stdio":current,"source_and_restored_accounting":want,
            "same_operation_same_receipt":True,"new_operation_denial":denied,"both_inference_fences":True,
            "post_fence_supervisor":outcome["status"],"bridge_rows":refs(kernel),
            "local_fixture_provider_http_calls":len(case["requests"]),"paid_external_model_calls":0}


def main():
    if not __debug__:
        raise RuntimeError("Run the qualified scenario without Python optimization")
    source_sha=os.environ["NF_BRIDGE_SOURCE_SHA"]
    actual=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
    tree=subprocess.check_output(["git","rev-parse","HEAD^{tree}"],text=True).strip()
    dirty=subprocess.check_output(["git","status","--porcelain","--untracked-files=normal"],text=True).strip()
    check(actual==source_sha and not dirty,"Source checkout must be clean and exact")
    source_file=Path("scripts/pitr_drill.py").resolve()
    original=source_file.read_text()
    source_hash=sha256(original.encode()).hexdigest()
    scope = {"__name__":"__main__","__file__":str(source_file),"refs":refs,"seed_bridge":seed,
             "later_settlement":later_settlement,"restored_witness":restored_witness,
             "product_sha":actual,"product_tree":tree,"p4_script_sha256":source_hash,
             "driver_sha256":sha256(Path(__file__).read_bytes()).hexdigest()}
    edits=[
        ('        base_started = time.monotonic()',
         '        result["bridge_rows_at_basebackup"] = refs(kernel)\n'
         '        _check(not any(refs(kernel).values()), "Expected pre-Bridge base image")\n'
         '        base_started = time.monotonic()'),
        ('        backup_service = OnlineBackupService(database.engine, objects, pg_bin=pg_bin)',
         '        bridge_case = seed_bridge(bridge_stack, kernel, source_url)\n'
         '        backup_service = OnlineBackupService(database.engine, objects, pg_bin=pg_bin)'),
        ('        later = transfer(target["world_ref"], "7", 30)',
         '        result["bridge_excluded_post_target_settlement"] = later_settlement(kernel, bridge_case)\n'
         '        later = transfer(target["world_ref"], "7", 30)'),
        ('"recovery_target_name": "nf_p4_verified_target", "recovery_target_action": "promote"',
         '"recovery_target_lsn": str(target_lsn), "recovery_target_inclusive": "on", "recovery_target_action": "promote"'),
        ('        _write(root / "target_database_digests.json", recovered_snapshot)',
         '        result["bridge_physical_witness"] = restored_witness(recovered, recovered_url, bridge_case)\n'
         '        result.update(product_sha=product_sha,product_tree=product_tree,p4_script_sha256=p4_script_sha256,'
         'fixture_driver_sha256=driver_sha256,model_calls=1,paid_external_model_calls=0,'
         'model_call_kind="local synthetic provider HTTP; no commercial model")\n'
         '        with recovered.db.engine.connect() as conn:\n'
         '            result["all_unknown_call_count"] = conn.scalar(text("SELECT count(*) FROM nf_call_attempts WHERE state=\'UNKNOWN\'"))\n'
         '        _check(result["all_unknown_call_count"] == 2, "Base and Bridge UNKNOWN must both be present")\n'
         '        _write(root / "target_database_digests.json", recovered_snapshot)')
    ]
    for before, after in edits:
        check(original.count(before)==1,"Pinned P4 hook changed: "+before)
        original=original.replace(before,after)
    # Preserve the original cleanup but mark a supplementary assertion failure before finalization.
    original=original.replace('        _write(root / "fenced_tasks.json", fenced)\n    finally:',
                              '        _write(root / "fenced_tasks.json", fenced)\n'
                              '    except BaseException:\n        result["status"] = "FAILED"\n        raise\n    finally:')
    sys.path[:0]=[str(source_file.parent),str(source_file.parents[1]/"tests/integration")]
    with ExitStack() as stack:
        scope["bridge_stack"]=stack
        exec(compile(original,str(source_file),"exec"),scope)


if __name__=="__main__":
    main()
