import os,pathlib,sys,hashlib
src,dst=map(pathlib.Path,sys.argv[1:])
if dst.exists():
 if src.read_bytes()!=dst.read_bytes(): raise RuntimeError('WAL archive collision')
else:
 tmp=dst.with_suffix('.partial')
 with tmp.open('wb') as f:
  f.write(src.read_bytes());f.flush();os.fsync(f.fileno())
 os.replace(tmp,dst)
 fd=os.open(dst.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
