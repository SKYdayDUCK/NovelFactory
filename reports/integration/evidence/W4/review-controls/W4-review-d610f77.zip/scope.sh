set -eu
base=/workspace/scratch/eb2b53c756d0
cd "$base/w4-review-audit/workshop"
export AW_DATABASE_URL="${NF_DATABASE_URL/postgresql+psycopg/postgresql}"
export AW_W4_LEGACY_REVIEW_EVIDENCE="$base/w4-review-evidence/$1-legacy.json"
export PYTHONPATH="$PWD/src"
python="$base/qual-w3/aw/workshop/.venv/bin/python"
"$python" -m alembic upgrade head
"$python" -m pytest -q tests/test_review_team_assignment.py tests/test_reviews_skills.py tests/test_legacy_paid_reviews.py -o junit_family=xunit1 --junitxml="$base/w4-review-evidence/$1.xml"
