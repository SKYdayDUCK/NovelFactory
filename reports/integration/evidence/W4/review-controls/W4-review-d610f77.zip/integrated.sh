set -eu
base=/workspace/scratch/eb2b53c756d0
export PATH="$base/qualification-w2/redis-build/redis-8.0.2/src:$PATH"
redis-server --version
cd "$base/w4-review-on-signed-w3/workshop"
export AW_DATABASE_URL="${NF_DATABASE_URL/postgresql+psycopg/postgresql}"
export AW_W4_LEGACY_REVIEW_EVIDENCE="$base/w4-review-evidence/$1-legacy.json"
export PYTHONPATH="$PWD/src"
python="$PWD/.venv/bin/python"
"$python" -I -c 'import agent_workshop; print("Installed AW package", agent_workshop.__file__)' 
"$python" -m alembic upgrade head
"$python" -m pytest -q tests/test_review_team_assignment.py tests/test_reviews_skills.py tests/test_legacy_paid_reviews.py tests/test_delegation*.py -o junit_family=xunit1 --junitxml="$base/w4-review-evidence/$1.xml"
export AW_NF_SOURCE="$base/w4-review-on-signed-w3"
export AW_DUAL_TEST_ADMIN_URL="${AW_DATABASE_URL%/*}/postgres"
export AW_PAIRED_RESTORE_EVIDENCE="$base/w4-review-evidence/$1-paired.json"
export PYTHONPATH="$AW_NF_SOURCE/workshop/src:$AW_NF_SOURCE/src:$AW_NF_SOURCE"
cd "$AW_NF_SOURCE"
"$AW_NF_SOURCE/.venv/bin/python" -m pytest -q -c pyproject.toml workshop/integration/test_dual_stdio.py workshop/integration/test_paired_restore.py --junitxml="$base/w4-review-evidence/$1-dual.xml"
