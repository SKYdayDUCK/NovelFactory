"""Observe original ReviewService call returns without altering methods, SQL or requests."""
import hashlib
import json
import os
from pathlib import Path
import sys

import pytest
from novel_factory.application.editorial import ReviewService


@pytest.fixture(autouse=True)
def observe_original_calls(record_property):
    read_code = ReviewService.read_text.__code__
    report_code = ReviewService.submit_review.__code__
    reads = []
    reports = []

    def observe(frame, event, result):
        if event != "return" or result is None:
            return
        if frame.f_code is read_code:
            text = result["text"]
            span = result["span"]
            digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
            reads.append({"task_id": frame.f_locals["task_id"], "generation": frame.f_locals["generation"],
                          "coverage_ref": result["coverage_ref"], "delivery_ref": result["delivery_ref"],
                          "text_ref": result["text_ref"], "draft_ref": result["draft_ref"],
                          "span": span, "read_mode": frame.f_locals["read_mode"],
                          "delivered_codepoints": len(text), "delivered_bytes": len(text.encode("utf-8")),
                          "delivered_sha256": digest})
        elif frame.f_code is report_code:
            request = frame.f_locals["request"]
            reports.append({"task_id": request["task_id"], "generation": request["generation"],
                            "nf_report": result, "coverage_refs": request["coverage_refs"],
                            "scale": request["scale"], "dimension": request["dimension"]})

    old = sys.getprofile()
    sys.setprofile(observe)
    try:
        yield
    finally:
        sys.setprofile(old)
    assert len(reads) == 1
    read = reads[0]
    assert read["delivered_sha256"] == read["text_ref"]["sha256"]
    assert read["span"]["start"] == 0 and read["span"]["end"] == read["delivered_codepoints"]
    assert read["read_mode"] == "FULL_TEXT" and len(reports) == 2 and reports[0] == reports[1]
    assert reports[0]["coverage_refs"] == [read["coverage_ref"]]
    assert reports[0]["task_id"] == read["task_id"] and reports[0]["generation"] == read["generation"]
    result = {"read":read,"submitted_review":reports[0],"idempotent_report_submissions":2}
    Path(os.environ["AW_W4_OBSERVED_COVERAGE"]).write_text(json.dumps(result, indent=2) + "\n")
    record_property("observed_coverage", json.dumps(result))
