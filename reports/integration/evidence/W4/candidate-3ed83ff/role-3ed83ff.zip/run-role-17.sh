#!/usr/bin/env bash
set -euo pipefail
checkout=$(realpath "$1")
expected=$2
out=$(realpath -m "$3")
runtime=/workspace/scratch/280a737fadfd/recovery
baseline="$runtime/nfbridge-ci/main-15f606c/integrity/raw/p1-postgres-concurrency-1/postgres-all.json"
cd "$checkout"
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
mkdir "$out"
git show -s --format='%H%n%T%n%P' HEAD > "$out/source.txt"
git ls-tree HEAD src adapters tests migrations scripts pyproject.toml uv.lock .github/workflows/p1-integrity.yml > "$out/roots.txt"
export PG_BIN="$runtime/pg17/dist/usr/lib/postgresql/17/bin"
export PATH="$runtime/codex/node_modules/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/bin:$PG_BIN:$PATH" LD_LIBRARY_PATH="$runtime/pg17/dist/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export NF_P5_CODEX_VERSION=0.167.0-alpha.4
uv sync --locked --offline --group dev
test "$(codex --version)" = "codex-cli $NF_P5_CODEX_VERSION"
{ uname -srmo; codex --version; bwrap --version; unshare --version; cc --version; postgres --version; .venv/bin/python --version; } > "$out/environment.txt"
.venv/bin/python scripts/with_postgres.py --pg-bin "$PG_BIN" --log-dir "$out/pg" --migrate -- .venv/bin/python -m pytest -q -rs \
  tests/integration/test_p5_actor_tool_choice.py tests/integration/test_p5_supervised_role_read.py tests/integration/test_p5_role_container.py \
  --junitxml="$out/role-17.xml" --json-report --json-report-file="$out/role-17.json" > "$out/run.log" 2>&1
.venv/bin/python - "$baseline" "$out/role-17.json" "$out/verification.json" <<'PY'
import json,sys
from pathlib import Path
baseline,local,out=map(Path,sys.argv[1:])
p1=json.loads(baseline.read_text()); result=json.loads(local.read_text())
expected={t["nodeid"] for t in p1["tests"] if t["outcome"]=="skipped"}
actual={t["nodeid"] for t in result["tests"] if t["outcome"]=="passed"}
if len(expected)!=17 or actual!=expected or len(result["tests"])!=17 or result["exitcode"]!=0:
    raise RuntimeError(f"Expected all 17 hosted skips to pass; {result['summary']}; unmatched={expected ^ actual}")
out.write_text(json.dumps({"baseline_main":"15f606c99c765deeffd904ad540441eb6476b3af","matches_hosted_skips":True,"nodeids":sorted(actual),"summary":result["summary"]},indent=2)+"\n")
PY
test -z "$(git status --porcelain)"
tail -2 "$out/run.log"
