#!/usr/bin/env python3
"""Run W4 review and skill checks alongside W3 migration, messaging, stdio and physical recovery on two private PG17.11 services."""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import tempfile
import time
from xml.etree import ElementTree

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("checkout", type=Path)
parser.add_argument("results", type=Path)
args = parser.parse_args()
repo, output = args.checkout.resolve(), args.results.resolve()
nf_python = repo/".venv/bin/python"
aw_dir = repo/"workshop"
aw_python = aw_dir/".venv/bin/python"
for exe, cwd, extra in ((nf_python, repo, []), (aw_python, aw_dir, ["--extra", "streams"])):
    if not exe.exists():
        subprocess.run(["uv", "sync", "--locked", *extra], cwd=cwd, check=True)
if Path(sys.prefix).resolve() != nf_python.parents[1].resolve():
    os.execv(nf_python, [str(nf_python), str(Path(__file__).resolve()), str(repo), str(output)])

import psycopg
from psycopg import sql
from sqlalchemy.engine import URL

runtime = Path(__file__).resolve().parents[1]
pg_bin = Path(os.getenv("PG_BIN", runtime/"pg17/dist/usr/lib/postgresql/17/bin")).resolve()
redis_bin = Path(os.getenv("REDIS_BIN", runtime/"redis-debian/dist/usr/bin")).resolve()
redis_lib = redis_bin.parent/"lib/x86_64-linux-gnu"
env = {**os.environ, "LD_LIBRARY_PATH": str(redis_lib)+os.pathsep+os.getenv("LD_LIBRARY_PATH",""),
       "PATH": str(pg_bin)+os.pathsep+str(redis_bin)+os.pathsep+os.environ["PATH"],
       "PG_BIN":str(pg_bin), "AW_NF_SOURCE":str(repo), "AW_W0_PYTHON":str(aw_python),
       "PYTHONDONTWRITEBYTECODE":"1", "PYTHONPATH":str(aw_dir/"src")+os.pathsep+str(repo/"src")}
output.mkdir(parents=True, exist_ok=True)
if (output/"runtime.json").exists():
    output = Path(tempfile.mkdtemp(prefix="attempt-", dir=output))
print(f"W4 evidence: {output}", flush=True)

def capture(command):
    return subprocess.check_output(command, cwd=repo, text=True, env=env).strip()


def record(path, data):
    (output/path).write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n")


def source():
    tracked = capture(["git","status","--porcelain","--untracked-files=normal","--",
                       "src","workshop","migrations","scripts","tests"])
    return {"head":capture(["git","rev-parse","HEAD"]), "tree":capture(["git","rev-parse","HEAD^{tree}"]),
            "changed_paths":tracked.splitlines(),
            "tracked_diff_sha256":hashlib.sha256(subprocess.check_output(
                ["git","diff","--no-ext-diff","--binary","HEAD","--","src","workshop","migrations","scripts","tests"],cwd=repo)).hexdigest()}


def free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def url(role, password, port, database, dialect="postgresql"):
    return URL.create(dialect, username=role, password=password, host="127.0.0.1",
                      port=port, database=database).render_as_string(hide_password=False)


@contextmanager
def postgres(base, identity):
    port, password = free_port(), secrets.token_urlsafe(24)
    data, pwfile = base/(identity+"-data"), base/(identity+"-pw")
    with os.fdopen(os.open(pwfile, os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),"w") as f:
        f.write(password+"\n")
    with (output/(identity+"-init.log")).open("w") as log:
        subprocess.run([pg_bin/"initdb", "-D", data, "-U", "postgres", "--encoding=UTF8", "--locale=C",
                        "--auth-local=reject","--auth-host=scram-sha-256","--pwfile",pwfile,"--data-checksums"],
                       env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    pwfile.unlink()
    with (data/"postgresql.conf").open("a") as config:
        config.write(f"\nport={port}\nlisten_addresses='127.0.0.1'\nunix_socket_directories=''\n"
                     "timezone='UTC'\nmax_connections=80\n")
    subprocess.run([pg_bin/"pg_ctl","-D",data,"-l",output/(identity+"-postgres.log"),"-w","start"],
                   env=env, check=True, stdout=subprocess.DEVNULL)
    try:
        yield port, url("postgres",password,port,"postgres")
    finally:
        subprocess.run([pg_bin/"pg_ctl","-D",data,"-w","-m","fast","stop"],env=env,
                       check=True,stdout=subprocess.DEVNULL)


@contextmanager
def redis_server(base):
    port=free_port()
    with (output/"redis.log").open("w") as log:
        child=subprocess.Popen([redis_bin/"redis-server","--bind","127.0.0.1","--port",str(port),
            "--dir",base,"--save","","--appendonly","no"],env=env,stdout=log,stderr=subprocess.STDOUT)
        try:
            for _ in range(100):
                if child.poll() is not None: raise RuntimeError("Redis exited during startup")
                p=subprocess.run([redis_bin/"redis-cli","-p",str(port),"ping"],capture_output=True,env=env)
                if p.stdout.strip()==b"PONG": break
                time.sleep(.05)
            else: raise TimeoutError("Redis did not answer PING")
            yield f"redis://127.0.0.1:{port}/0"
        finally:
            child.terminate()
            child.wait(timeout=10)


def provision(admin, role, databases, createdb=False):
    pwd=secrets.token_urlsafe(24)
    with psycopg.connect(admin, autocommit=True) as c:
        c.execute(sql.SQL("CREATE ROLE {} LOGIN {} PASSWORD {}").format(
            sql.Identifier(role),sql.SQL("CREATEDB" if createdb else "NOCREATEDB"),sql.Literal(pwd)))
        for db in databases:
            c.execute(sql.SQL("CREATE DATABASE {} OWNER {}").format(sql.Identifier(db),sql.Identifier(role)))
            c.execute(sql.SQL("REVOKE CONNECT ON DATABASE {} FROM PUBLIC").format(sql.Identifier(db)))
    return pwd


def cluster_id(dsn):
    with psycopg.connect(dsn) as conn:
        return str(conn.execute("SELECT system_identifier FROM pg_control_system()").fetchone()[0])


def service_authority(dsn, versions):
    with psycopg.connect(dsn.replace("postgresql+psycopg:", "postgresql:")) as conn:
        authority = conn.execute("SELECT current_user, current_database(), rolsuper, rolcreaterole, rolcreatedb "
                                 "FROM pg_roles WHERE rolname=current_user").fetchone()
        assert authority[2:] == (False,False,False)
        rev = conn.execute(sql.SQL("SELECT version_num FROM {}").format(sql.Identifier(versions))).fetchall()
        assert len(rev)==1
        return {"login":authority[0],"database":authority[1],"superuser":False,"createrole":False,
                "createdb":False,"schema_revision":rev[0][0]}


def step(name, command, cwd, *junit):
    with (output/(name+".log")).open("w") as log:
        subprocess.run(command,env=env,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,check=True)
    if junit:
        s=ElementTree.parse(output/junit[0]).find(".//testsuite")
        assert s is not None and int(s.get("tests"))>0 and all(int(s.get(k,0))==0 for k in ("skipped","errors","failures"))
        return int(s.get("tests"))


def tests(name, python, cwd, paths):
    xml=name+".xml"
    return step(name,[python,"-m","pytest","-c","pyproject.toml","-q","-o","junit_family=xunit1",
                      *paths, "--junitxml="+str(output/xml)], cwd, xml)


info={"source":source(),"postgres":capture([pg_bin/"postgres","--version"]),
      "redis":capture([redis_bin/"redis-server","--version"]), "utc_started":datetime.now(timezone.utc).isoformat(),
      "runner_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      "redis_scope":"Dedicated Redis server process; real Streams delivery and consumer-group restart."}
assert "PostgreSQL) 17.11" in info["postgres"] and "v=8." in info["redis"]
record("runtime.json",info)
with tempfile.TemporaryDirectory(prefix="aw-w4-") as workspace:
    tmp=Path(workspace)
    with postgres(tmp,"aw") as (aw_port,aw_admin), postgres(tmp,"nf") as (nf_port,nf_admin), redis_server(tmp) as redis_url:
        assert aw_port!=nf_port
        systems={"aw":cluster_id(aw_admin),"nf":cluster_id(nf_admin)}
        assert systems["aw"]!=systems["nf"]
        historical={"AW_UPGRADE_DATABASE_URL":"w0_source","AW_W2_FROM_W1_DATABASE_URL":"w1_source",
                    "AW_W2_FROM_W2_DATABASE_URL":"w2_source","AW_W3_FROM_W2C_DATABASE_URL":"w2c_source",
                    "AW_W3_FROM_W3_DATABASE_URL":"w3_source","AW_W3_FROM_W3A_DATABASE_URL":"w3a_source",
                    "AW_W4_FROM_W3_DATABASE_URL":"w4_from_w3","AW_W4_FROM_W4_DATABASE_URL":"w4_from_w4",
                    "AW_W4_FROM_W4B_DATABASE_URL":"w4_from_w4b"}
        aw_pass=provision(aw_admin,"aw_service",["aw_w3","w4_from_w3_route",*historical.values()])
        nf_pass=provision(nf_admin,"nf_service",["nf_w3"])
        env.update(AW_DUAL_TEST_ADMIN_URL=aw_admin,AW_DUAL_TEST_NF_ADMIN_URL=nf_admin,
                   AW_DATABASE_URL=url("aw_service",aw_pass,aw_port,"aw_w3"),
                   NF_DATABASE_URL=url("nf_service",nf_pass,nf_port,"nf_w3","postgresql+psycopg"),
                   AW_REDIS_TEST_URL=redis_url,AW_REDIS_URL=redis_url,
                   AW_PAIRED_RESTORE_EVIDENCE=str(output/"paired-restore.json"),
                   AW_W3_REDIS_EVIDENCE=str(output/"w3-redis-recovery.json"),
                   AW_W4_LEGACY_REVIEW_EVIDENCE=str(output/"w4-legacy-review.json"),
                   AW_W4_SKILLS_EVIDENCE=str(output/"w4-skills-stdio.json"),
                   AW_W4_ROUTING_UPGRADE_EVIDENCE_DIR=str(output/"w4-route-upgrades"),
                   AW_W2_TRANSPORT_EVIDENCE=str(output/"redis-transport.json"))
        for key,db in historical.items():env[key]=url("aw_service",aw_pass,aw_port,db)
        for role,password,p,database in (("aw_service",aw_pass,nf_port,"nf_w3"),("nf_service",nf_pass,aw_port,"aw_w3")):
            try:
                with psycopg.connect(url(role,password,p,database)): pass
            except psycopg.OperationalError: pass
            else: raise AssertionError("Peer accepted another service's credentials")
        info.update(postgres_system_ids=systems,aw_postgres_port=aw_port,nf_postgres_port=nf_port,redis_port=int(redis_url.split(":")[-1].split("/")[0]),
                    postgres_authentication="scram-sha-256", cross_server_access="both rejected")
        record("runtime.json",info)
        step("migrate-nf",[nf_python,"-m","alembic","upgrade","head"],repo)
        step("migrate-aw",[aw_python,"-m","alembic","upgrade","head"],aw_dir)
        info["authority"]={"aw":service_authority(env["AW_DATABASE_URL"],"aw_alembic_version"),
                           "nf":service_authority(env["NF_DATABASE_URL"],"alembic_version")}
        record("runtime.json",info)
        suites={}
        (output/"w4-route-upgrades").mkdir()
        stage_tests={str(x.relative_to(aw_dir)) for pattern in ("test_*delegat*.py","test_*handoff*.py","test_*w3*.py",
                                                          "test_*review*.py","test_*w4*.py","test_*skill*.py")
                     for x in (aw_dir/"tests").glob(pattern)}
        suites["stage-pg"]=tests("stage-pg",aw_python,aw_dir,sorted(stage_tests|{"tests/test_live_mailbox.py"}))
        suites["signed-w3-ledgers"]=tests("signed-w3-ledgers",aw_python,aw_dir,["acceptance/test_w4_historical_upgrade.py"])
        env["AW_W4_FROM_W3_DATABASE_URL"]=url("aw_service",aw_pass,aw_port,"w4_from_w3_route")
        suites["historical-upgrades"]=tests("historical-upgrades",aw_python,aw_dir,
            ["acceptance/test_w1_historical_upgrade.py","acceptance/test_w2_historical_upgrades.py",
             "acceptance/test_w3_historical_upgrades.py","acceptance/test_w4_historical_upgrades.py"])
        suites["bridge-stdio"]=tests("bridge-stdio",nf_python,repo,["workshop/acceptance/test_nf_bridge_stdio.py",
                                                                 "workshop/acceptance/test_w0_dual_services.py"])
        suites["dual-stdio-pitr"]=tests("dual-stdio-pitr",nf_python,repo,["workshop/integration"])
        for name in ("w3-redis-recovery.json","paired-restore.json","w4-legacy-review.json","w4-skills-stdio.json"):
            assert json.loads((output/name).read_bytes()), name
        for origin in ("w004","w004a","w004b","signed-view"):
            assert json.loads((output/"w4-route-upgrades"/(origin+".json")).read_bytes()), origin
        info.update(suites=suites,utc_finished=datetime.now(timezone.utc).isoformat(),source_after=source())
        info["verified_clean_checkout"] = info["source"] == info["source_after"] and not info["source"]["changed_paths"]
        record("runtime.json",info)
        print(json.dumps(suites),flush=True)
