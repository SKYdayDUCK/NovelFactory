#!/usr/bin/env bash
set -eu -o pipefail
cd "$NF_REPO"
D="$NFQ_RUN/evidence"
export AW_ROUTE_MATRIX_EVIDENCE="$D/routing-matrix.json"
export AW_W2_TRANSPORT_EVIDENCE="$D/w2-transport.json"
export NF_W0_TOOL_MATRIX="$D/nf-tools.json"
git rev-parse HEAD > "$D/head.txt"
git status --short --branch > "$D/checkout.txt"
echo "W2 test source $(cat "$D/head.txt")"
run_test(){
 name="$1"; shift
 if "$@" > "$D/$name.log" 2>&1; then tail -1 "$D/$name.log"; else echo "$name failed; see private log"; return 1; fi
}
RET=0
( cd workshop && run_test workshop .venv/bin/python -m pytest tests -q -rs --junitxml="$D/workshop.xml" ) || RET=1
( cd workshop && run_test upgrade-w0 .venv/bin/python -m pytest -c pyproject.toml acceptance/test_w1_historical_upgrade.py -q -o junit_family=xunit1 --junitxml="$D/upgrade-w0.xml" ) || RET=1
( cd workshop && run_test upgrade-w1-w2 .venv/bin/python -m pytest -c pyproject.toml acceptance/test_w2_historical_upgrades.py -q -o junit_family=xunit1 --junitxml="$D/upgrade-w1-w2.xml" ) || RET=1
PYPATH="$PWD/workshop/qualification:$PWD/src"
PYTHONPATH="$PYPATH" run_test nf-tools .venv/bin/python -m pytest -p matrix_probe -q tests/integration/test_p5_mcp.py tests/integration/test_p5_rolling.py --junitxml="$D/nf-tools.xml" || RET=1
run_test dual-services .venv/bin/python -m pytest -c pyproject.toml workshop/acceptance/test_w0_dual_services.py -q -o junit_family=xunit1 --junitxml="$D/dual-services.xml" || RET=1
(
 cd workshop
 .venv/bin/python - <<'PY'
from pathlib import Path
import os
target = Path(os.environ["NFQ_RUN"]) / "test_w2_native_outage.py"
src = Path("tests/test_notifications.py").read_text()
stop='subprocess.run(["docker", "stop", "-t", "2", container], check=True, capture_output=True)'
start='subprocess.run(["docker", "start", container], check=True, capture_output=True)'
assert src.count(stop)==1 and src.count(start)==1
src=src.replace(stop,'subprocess.run([os.environ["NRD"] + "/redis-cli", "-p", "25623", "shutdown", "nosave"], check=True, capture_output=True)')
src=src.replace(start,'subprocess.run([os.environ["NRD"] + "/redis-server", os.environ["NFQ_RUN"] + "/data/redis.conf"], check=True, capture_output=True)')
src=src.replace('os.environ.get("AW_REDIS_TEST_CONTAINER")','os.environ.get("NFQ_RUN")').replace('    container = os.environ["AW_REDIS_TEST_CONTAINER"]\n','')
target.write_text(src)
PY
 run_test native-outage .venv/bin/python -m pytest -c pyproject.toml "$NFQ_RUN/test_w2_native_outage.py::test_postgres_mail_during_redis_outage_and_new_worker_processes" -q --junitxml="$D/native-outage.xml"
) || RET=1
git rev-parse HEAD > "$D/end-head.txt"
exit "$RET"
