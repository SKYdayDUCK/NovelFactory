# #17 hosted shared-budget verification

The two scopes record independent executed GitHub jobs on the pull request and main push. In each scope, ref-chain.json identifies the candidate, base and actual checkout. Run the following from inside this extracted archive.

    sha256sum --check SHA256SUMS

    python verify_run.py --metadata-dir pr17/workshop --archives pr17/workshop/archives --checkout-sha 9529840b7b7138fc129bc795355a7f91bda6c781

Original JUnit, NF migration, WAL result, original Workshop ZIP files, and per-job checkout excerpts are included. Capacity records give the original artifact SHA256, path, member SHA256 and measured values for each failure. Files named failed-capacity are field extracts. No raw database or private bindings are included. Business fixtures called no commercial provider, and no literary judgment is made.
