# Replaying the local C1 checks

Use a disposable clone with the full Git history, the repository's locked NovelFactory and Workshop Python dependencies, PostgreSQL 17 server and client binaries, and Redis. The probe scripts read a local ephemeral database created by scripts/with_postgres.py. Their project bindings are generated inside temporary directories. Extract this archive to a separate directory and set RECEIPTS to its absolute path. Set PG_BIN to the PostgreSQL 17 bin directory. Use an empty absolute directory named by OUT to receive new observations. The probes and tests generate their own synthetic IDs.

From a clean candidate checkout at f96d26bcf449d8e7905099402ddb4ddcf8679a60:

    export PYTHONPATH="$PWD/src:$PWD"
    .venv/bin/python scripts/with_postgres.py --pg-bin "$PG_BIN" -- .venv/bin/python -m pytest -q tests/integration/test_shared_token_budget.py tests/integration/test_shared_token_upgrade.py --junitxml="$OUT/fixed.xml"
    .venv/bin/python scripts/with_postgres.py --pg-bin "$PG_BIN" -- .venv/bin/python "$RECEIPTS/cancel-fixed/cli-probe.py" "$OUT/cli.json"
    .venv/bin/python scripts/with_postgres.py --pg-bin "$PG_BIN" -- .venv/bin/python "$RECEIPTS/cancel-fixed/legacy-cancel-probe.py" "$OUT/legacy-cancel.json"

The second command produces observations of public cancellation. Compare rules.public_task_cancel before_prepared and after_task_cancel for equality on the fixed source. The legacy probe itself asserts the same cancellation receipt was replayed twice, only one command was stored, and the remaining SENT attempt was still fully charged. Both probes archive the real historical commit 4e8fc5a3c2331a0de669ad8851d82c5b08a1e5dc, execute it on its own import path and then run the actual migration.

To reproduce the two failures, use another disposable checkout of the same candidate with its final tests. Reverse the exact production diff in that checkout only:

    git apply --reverse "$RECEIPTS/replay/cancel-fix.patch"
    git hash-object src/novel_factory/orchestration/tasks.py
    .venv/bin/python scripts/with_postgres.py --pg-bin "$PG_BIN" -- .venv/bin/python -m pytest -q --tb=line tests/integration/test_shared_token_budget.py -k cancel --junitxml="$OUT/before.xml"

The production blob must now be f0131ea98cca8aaeb0db03878c3bec1a3c3bd542. Expected exit status is 1, with two failed and two passed nodes. The original before/after pair and the public replay use the same test blob. Raw initial and post-fix five-module commands are in their respective pg/postgres_session.json files. For the conditional recovery rerun, set NF_TEST_REDIS_URL to a dedicated disposable Redis test instance prior to executing the command in cancel-fixed/redis-pg/postgres_session.json. Set output directories for replay on your machine.

The actual paired run was started from the directory containing the p6-budget checkout with:

    runtime/with-services p6-budget/.venv/bin/python runtime/c1-final-paired.py

The runner is included byte-for-byte as replay/c1-final-paired.py. On another host with a sibling p6-budget candidate checkout and its Python environment, PostgreSQL 17 binaries in PG_BIN and on PATH, and redis-server on PATH, the runner creates its two SCRAM-authenticated test database endpoints. Create its relative output directory before starting it. The recorded orchestration command used the workspace's disposable services wrapper. The actual pytest argv, service variables and temporary directory handling are visible in the runner.

    mkdir -p acceptance_receipts/phase_c1/paired/final-candidate
    p6-budget/.venv/bin/python "$RECEIPTS/replay/c1-final-paired.py"

The three WAL positions are compared in paired/final-candidate/paired-final.json. Cross-check the original attempt ID and token amounts with the Workshop observations, and the corresponding operation IDs with offline-final.json and redis-cancel.json. The Redis interruption and the PITR scenario create separate operations; their operation IDs differ.
