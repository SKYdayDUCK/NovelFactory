import os
from contextlib import ExitStack
from pathlib import Path
import secrets
import socket
import subprocess
import sys
from tempfile import TemporaryDirectory

root = Path.cwd()
source = root / 'p6-budget'
out = root / 'acceptance_receipts/phase_c1/paired/final-candidate'
pg = Path(os.environ['PG_BIN'])
env = {**os.environ, 'AW_NF_SOURCE': str(source), 'AW_ACCEPTANCE_OUTPUT': str(out),
       'AW_BENCH_RESULTS': str(out), 'NF_P5_CODEX_VERSION':'0.167.0-alpha.4',
       'PYTHONPATH': os.pathsep.join(str(p) for p in [source/'workshop/src', source/'src', source]),
       'PATH': str(source/'.venv/bin') + os.pathsep + os.environ['PATH']}
with TemporaryDirectory(prefix='c1-cross-services-') as temp, ExitStack() as end:
    base = Path(temp)
    for name, var in [('aw','AW_DUAL_TEST_ADMIN_URL'), ('nf','AW_DUAL_TEST_NF_ADMIN_URL')]:
        db = base/name
        pw = secrets.token_hex(20)
        pwfile = base/(name+'.pw')
        pwfile.write_text(pw+'\n')
        pwfile.chmod(0o600)
        subprocess.run([pg/'initdb', '-D', db, '-U', 'fixture_admin','--pwfile',pwfile,
                        '--auth-local=reject','--auth-host=scram-sha-256','--locale=C','-E','UTF8'],check=True,stdout=subprocess.DEVNULL)
        with socket.socket() as listener:
            listener.bind(('127.0.0.1',0))
            port = listener.getsockname()[1]
        with (db/'postgresql.conf').open('a') as f:
            f.write(f"\nlisten_addresses='127.0.0.1'\nport={port}\nunix_socket_directories=''\n")
        subprocess.run([pg/'pg_ctl','-w','-D',db,'-l',base/(name+'.log'),'start'],check=True)
        end.callback(subprocess.run,[pg/'pg_ctl','-m','fast','-w','-D',db,'stop'])
        env[var]=f'postgresql://fixture_admin:{pw}@127.0.0.1:{port}/postgres'
    env.update(AW_PAIRED_RESTORE_EVIDENCE=str(out/'paired-final.json'),AW_W3_REDIS_EVIDENCE=str(out/'redis-cancel.json'),AW_OFFLINE_WITNESS=str(out/'offline-final.json'))
    result=subprocess.run([sys.executable, '-m','pytest','-c','pyproject.toml','-q','-o','junit_family=xunit1','workshop/integration/test_dual_stdio.py','workshop/integration/test_paired_restore.py','--basetemp='+str(base/'pytest'), '--junitxml='+str(out/'paired-and-cancel.xml')],cwd=source,env=env)
sys.exit(result.returncode)
