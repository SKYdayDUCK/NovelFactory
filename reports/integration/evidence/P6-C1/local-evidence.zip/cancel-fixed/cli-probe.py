"""Exercise the released 0017 binary, the 0018 CLI, and the authoritative attempts with generated loopback data."""
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

from sqlalchemy import text
from sqlalchemy.engine import make_url
from novel_factory.application.kernel import Kernel
from novel_factory.domain.errors import DomainError
from novel_factory.fixtures import load_fixture,create_bound_task,point
from novel_factory.infrastructure.database import Database
from novel_factory.infrastructure.objects import ObjectStore
from tests.fixtures.historical_release import run_release

repo=Path.cwd()
release='4e8fc5a3c2331a0de669ad8851d82c5b08a1e5dc'
out=Path(sys.argv[1]).resolve()
url=os.environ['NF_DATABASE_URL']
assert make_url(url).host=='127.0.0.1' and make_url(url).database=='nf_test'
result={'historical_commit':release,'historical_revision':'0017_nf_workshop_delegation','candidate_revision':'0018_p6_shared_tokens','provider_calls':0,'cli':{},'rules':{}}
with TemporaryDirectory(prefix='p6-contract-') as temp:
    private=Path(temp)
    original=run_release(repo,private,release,"""
import os
from pathlib import Path
from novel_factory.application.kernel import Kernel
from novel_factory.infrastructure.database import Database
from novel_factory.infrastructure.objects import ObjectStore
from novel_factory.fixtures import load_fixture,create_bound_task,point
from sqlalchemy import text
import json
k=Kernel(Database(),ObjectStore(os.environ['NF_OBJECT_ROOT']))
w=load_fixture(k)
wr=w['world_ref']
t=create_bound_task(k,w['principal'],wr,point(1))
budget=k.tasks.create_budget(wr['work_id'],'0.20')
calls={}
for tag in ('settled','uncertain'):
 call=k.tasks.reserve_call(t['task_id'],t['generation'],t['worker_id'],budget_id=budget,amount='0.10',call_key=tag,request_hash='a'*64,token_amount=10)
 k.tasks.mark_call_sent(call['attempt_id'],worker_id=t['worker_id'])
 if tag=='settled':
  k.tasks.settle_call(call['attempt_id'],state='SUCCEEDED',actual_amount='0.02',actual_tokens=6,provider_receipt='synthetic-six')
 else: k.tasks.settle_call(call['attempt_id'],state='UNKNOWN')
 calls[tag]=str(call['attempt_id'])
with k.db.uow(write=False) as r: assert r.conn.scalar(text('SELECT version_num FROM alembic_version'))=='0017_nf_workshop_delegation'
print(json.dumps({'token':w['token'],'world':wr,'task':{k:t[k] for k in ('task_id','generation','worker_id')},'calls':calls,'budget':budget}))
""",dict(os.environ))
    subprocess.run([sys.executable,'-m','alembic','upgrade','head'],cwd=repo,check=True)
    root=private/'objects'
    k=Kernel(Database(url),ObjectStore(root))
    try:
        budget=original['budget']
        work=original['world'];task=original['task']
        owner=k.authenticate(original['token'])
        def binding(path,token,wr):
            with os.fdopen(os.open(path,os.O_EXCL|os.O_WRONLY|os.O_CREAT,0o600),'w') as f:
                json.dump({'token':token,'database_url':url,'object_root':str(root),'binding':{q:wr[q] for q in ('work_id','branch_id')}},f)
            return path
        author=binding(private/'creator.json',original['token'],work)
        other=load_fixture(k)
        stranger=binding(private/'foreign.json',other['token'],other['world_ref'])
        def cli(label,caller,mode,*args,error=None):
            argv=[sys.executable,str(repo/'scripts/p6_budget.py'),'--binding',caller,mode,'--budget-id',budget,*args]
            proc=subprocess.run(argv,capture_output=True,text=True)
            if error:
                assert proc.returncode and proc.stderr.strip()==error and not proc.stdout,(label,proc.returncode,proc.stderr)
                row={'exit':proc.returncode,'error':proc.stderr.strip()}
            else:
                assert proc.returncode==0,(label,proc.stderr)
                row={'exit':0,'result':json.loads(proc.stdout)}
            result['cli'][label]=row
            return row.get('result')
        a=cli('legacy_usage',author,'show')
        assert a['total_tokens'] is None and a['spent_tokens']==6 and a['reserved_tokens']==10
        updated=cli('set_20',author,'set','--total-tokens','20')
        assert updated['available_tokens']==4 and updated['spent_amount']=='0.020000' and updated['reserved_amount']=='0.100000'
        assert updated==cli('set_20_replay',author,'set','--total-tokens','20')
        cli('foreign_show',stranger,'show',error='VIEW_DENIED')
        cli('foreign_update',stranger,'set','--total-tokens','90',error='VIEW_DENIED')
        cli('stale_edit',author,'set','--total-tokens','18','--expected-total-tokens','19',error='IDEMPOTENCY_CONFLICT')
        # Released (0017) code is still on its old import path; only the PostgreSQL trigger knows the new policy.
        program="""
import os,json
from pathlib import Path
from sqlalchemy.exc import IntegrityError
from novel_factory.application.kernel import Kernel
from novel_factory.infrastructure.database import Database
from novel_factory.infrastructure.objects import ObjectStore
assert Path(Kernel.__init__.__code__.co_filename).resolve().is_relative_to(Path.cwd()/'src')
k=Kernel(Database(),ObjectStore(os.environ['NF_OBJECT_ROOT']))
data=json.loads(input())
t=data['task']
try:
 k.tasks.reserve_call(t['task_id'],t['generation'],t['worker_id'],budget_id=data['budget'],amount='0.01',call_key='old-0017-binary',request_hash='b'*64,token_amount=5)
except IntegrityError as e:
 assert e.orig.diag.constraint_name=='ck_nf_shared_token_reservation'
 print(json.dumps({'constraint':e.orig.diag.constraint_name,'sqlstate':e.orig.sqlstate}))
else:raise AssertionError('Earlier client bypassed shared limit')
"""
        released=private/release
        old=subprocess.run([sys.executable,'-c',program],cwd=released,env={**os.environ,'PYTHONPATH':str(released/'src'),'NF_OBJECT_ROOT':str(root)},input=json.dumps({'task':task,'budget':budget}),text=True,capture_output=True,check=True)
        result['rules']['old_binary']=json.loads(old.stdout)
        assert cli('after_old_client_overrun',author,'show')==updated
        def reserve(task,key,n,amount):
            return k.tasks.reserve_call(task['task_id'],task['generation'],task['worker_id'],budget_id=budget,amount=amount,call_key=key,request_hash='c'*64,token_amount=n)
        def denied(key,op):
            try: op()
            except DomainError as e:
                assert e.code=='BUDGET_EXCEEDED',(key,e.code);result['rules'][key]={'error':e.code,'message':str(e)}
            else: raise AssertionError(key)
        denied('monetary_independent',lambda:reserve(task,'money',1,'0.09'))
        cli('set_60000',author,'set','--total-tokens','60000','--expected-total-tokens','20')
        denied('task_token_independent',lambda:reserve(task,'task_tokens',50001,'0.01'))
        prepared=reserve(task,'cancel_unsent',2,'0.01')
        k.tasks.settle_call(prepared['attempt_id'],state='FAILED',actual_amount='0',actual_tokens=0)
        view=cli('cancel_prepared',author,'show')
        assert view['available_tokens']==59984 and view['reserved_tokens']==10 and view['reserved_amount']=='0.100000'
        # Also observe cancellation via the public task authority so orphaned reservations cannot be masked by a lower-level explicit release.
        t2=create_bound_task(k,owner,work,point(1))
        reserve(t2,'cancel_via_task',3,'0.01')
        k.cancel_task(owner,t2['task_id'],t2['generation'],'cancel-via-authorized-kernel')
        observed=cli('after_public_task_cancel',author,'show')
        result['rules']['public_task_cancel']={'before_prepared':view,'after_task_cancel':observed}
        with k.db.uow(write=False) as r:
            result['active_revision']=r.conn.scalar(text('select version_num from alembic_version'))
        assert result['active_revision']==result['candidate_revision']
    finally:
        k.db.close()
out.write_text(json.dumps(result,indent=2)+'\n')
