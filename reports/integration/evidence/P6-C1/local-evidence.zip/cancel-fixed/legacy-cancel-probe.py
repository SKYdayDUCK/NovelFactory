"""Replay an old-version cancellation receipt on two budgets, retaining an already sent attempt."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json, os, subprocess, sys
from novel_factory.application.kernel import Kernel
from novel_factory.application.budget_limits import SharedBudgetService
from novel_factory.infrastructure.database import Database
from novel_factory.infrastructure.objects import ObjectStore
from tests.fixtures.historical_release import run_release
from sqlalchemy import text

root=Path.cwd()
release='4e8fc5a3c2331a0de669ad8851d82c5b08a1e5dc'
out=Path(sys.argv[1]).resolve()
with TemporaryDirectory(prefix='old-cancellation-') as tmp:
    data=run_release(root,Path(tmp),release,"""
from novel_factory.application.kernel import Kernel
from novel_factory.infrastructure.database import Database
from novel_factory.infrastructure.objects import ObjectStore
from novel_factory.fixtures import load_fixture,create_bound_task,point
import os, json
k=Kernel(Database(),ObjectStore(os.environ['NF_OBJECT_ROOT']))
w=load_fixture(k)
t=create_bound_task(k,w['principal'],w['world_ref'],point(1))
budgets=[k.tasks.create_budget(w['world_ref']['work_id'],'1') for _ in (0,1)]
calls=[]
for i,(budget,n,m) in enumerate([(budgets[1],6,'0.06'),(budgets[0],4,'0.04'),(budgets[0],3,'0.03')]):
 a=k.tasks.reserve_call(t['task_id'],t['generation'],t['worker_id'],budget_id=budget,amount=m,call_key=f'legacy-{i}',request_hash='a'*64,token_amount=n)
 calls.append(a['attempt_id'])
k.tasks.mark_call_sent(calls[-1],worker_id=t['worker_id'])
r=k.cancel_task(w['principal'],t['task_id'],t['generation'],'legacy-cancel')
print(json.dumps({'world':w['world_ref'],'token':w['token'],'budgets':budgets,'calls':calls,'receipt':r}))
""",dict(os.environ))
    subprocess.run([sys.executable,'-m','alembic','upgrade','head'],check=True)
    k=Kernel(Database(),ObjectStore(Path(tmp)/'objects'))
    try:
        service=SharedBudgetService(k); wr=data['world']; owner=k.authenticate(data['token']); orig=data['receipt']
        def status():
            return [service.status(owner,wr['work_id'],wr['branch_id'],b) for b in data['budgets']]
        def states():
            with k.db.uow(write=False) as repo:
                return [repo.one('call_attempts',{'attempt_id':a})['state'] for a in data['calls']]
        before=status(); before_states=states()
        assert before_states==['PREPARED','PREPARED','SENT'] and [x['reserved_tokens'] for x in before]==[7,6]
        for _ in range(2):
            assert k.cancel_task(owner,orig['task_id'],orig['generation'],'legacy-cancel')==orig
            assert states()==['FAILED','FAILED','SENT']
            after=status()
            assert [x['reserved_amount'] for x in after]==['0.030000','0.000000']
            assert [x['reserved_tokens'] for x in after]==[3,0]
        with k.db.uow(write=False) as repo:
            commands=repo.conn.scalar(text("select count(*) from nf_task_commands where idempotency_key='legacy-cancel'"))
        assert commands==1
        result={'status':'PASS','old_release':release,'original_cancel_receipt':orig,'same_cancel_retries':2,'command_count':commands,'before_upgrade_replay':before,'after_replay':after,'old_states':before_states,'after_states':states(),'provider_calls':0}
        out.write_text(json.dumps(result,indent=2)+'\n')
    finally: k.db.close()
