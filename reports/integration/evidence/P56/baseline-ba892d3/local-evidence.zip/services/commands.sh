#!/usr/bin/env bash
set -u
root="$(cd "$(dirname "$0")/../NovelFactory" && pwd)"
out="$root/../acceptance_receipts/phase_b/services"
mkdir -p "$out/routing-upgrades"
cd "$root"
export PYTHONDONTWRITEBYTECODE=1
export AW_ROUTE_MATRIX_EVIDENCE="$out/routing-matrix.json"
export AW_W2_TRANSPORT_EVIDENCE="$out/transport.json"
export AW_W4_SKILLS_EVIDENCE="$out/skills.json"
export AW_W4_LEGACY_REVIEW_EVIDENCE="$out/legacy-review.json"
export AW_W4_ROUTING_UPGRADE_EVIDENCE_DIR="$out/routing-upgrades"
export AW_W3_REDIS_EVIDENCE="$out/redis-rebuild.json"
export AW_OFFLINE_WITNESS="$out/offline-witness.json"
export AW_PAIRED_RESTORE_EVIDENCE="$out/paired-restore.json"
export PYTHONPATH="$root/workshop/src:$root/src:$root"
git show -s --format='commit=%H%ntree=%T%nparents=%P' > "$out/source.txt"
date -u > "$out/start-utc.txt"
(cd "$root/workshop" && unset PYTHONPATH && .venv/bin/python -m pytest --cache-clear -c pyproject.toml -q -o junit_family=xunit1 tests --junitxml="$out/workshop.xml" >"$out/workshop.log" 2>&1; echo "$?" >"$out/workshop.exit") &
pid_workshop=$!
(.venv/bin/python -m pytest -c pyproject.toml -q -o junit_family=xunit1 workshop/integration --junitxml="$out/integration.xml" >"$out/integration.log" 2>&1; echo "$?" >"$out/integration.exit") &
pid_int=$!
wait "$pid_int"
wait "$pid_workshop"
date -u > "$out/end-utc.txt"
cat "$out/workshop.exit" "$out/integration.exit"
