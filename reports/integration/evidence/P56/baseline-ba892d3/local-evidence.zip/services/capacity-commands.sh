#!/usr/bin/env bash
set -eu
root="$(cd "$(dirname "$0")/../NovelFactory" && pwd)"
out="$root/../acceptance_receipts/phase_b/services/capacity"
mkdir -p "$out"
export PYTHONDONTWRITEBYTECODE=1
export AW_BENCH_RESULTS="$out"
cd "$root/workshop"
date -u >"$out/start-utc.txt"
git show -s --format='commit=%H%ntree=%T%nparents=%P' HEAD >"$out/source.txt"
for n in 10 50 200; do
    database="aw_benchmark_b_$n"
    .venv/bin/python - "$database" <<'PY'
import os,sys
import psycopg
from psycopg import sql
name=sys.argv[1]
with psycopg.connect(os.environ['AW_DUAL_TEST_ADMIN_URL'],autocommit=True) as c:
    c.execute(sql.SQL('CREATE DATABASE {} OWNER aw_service').format(sql.Identifier(name)))
    c.execute(sql.SQL('REVOKE CONNECT ON DATABASE {} FROM PUBLIC').format(sql.Identifier(name)))
PY
    bench_url="${AW_DATABASE_URL%/*}/$database"
    AW_DATABASE_URL="$bench_url" .venv/bin/aw-migrate upgrade >"$out/message-$n-upgrade.log" 2>&1
    set +e
    AW_DATABASE_URL="$bench_url" .venv/bin/python benchmarks/message_capacity.py --employees "$n" --output "$out/messages-$n.json" >"$out/messages-$n.log" 2>&1
    echo "$?" >"$out/messages-$n.exit"
    set -e
done
export PYTHONPATH="$root/workshop/src:$root/src:$root"
"$root/.venv/bin/python" -m pytest -c pyproject.toml -o junit_family=xunit1 -q benchmarks/delegation_capacity.py --junitxml="$out/delegation.xml" >"$out/delegation.log" 2>&1 || { code=$?; echo "$code" >"$out/delegation.exit"; exit "$code"; }
echo 0 >"$out/delegation.exit"
date -u >"$out/end-utc.txt"
