# P5.6 创作世界与岗位业务链验收

基线为 PR #25 合并提交 `ba892d3a424be39efccb697232a5614b26609cc4`。同一提交上的 GitHub push 运行 `43137991893` 通过，PostgreSQL 工件 `13909176667` 中的 `postgres-all.xml` 为 817 项成功、17 项因 runner 不允许建立 Linux 角色容器而跳过。W6 三个 Workshop job 的原始 JUnit 和 JSON 属于上一个主线提交 `98a8bbed289a29d0326454c86dd3db54ac85ae5c`。两版本之间只修改六份集成台账/签收 Markdown。新加的用例由本轮独立 PG17 执行；本页的基线数据不预报新提交的 GitHub CI 结果。[NF 主线运行](https://github.com/SKYdayDUCK/NovelFactory/actions/runs/43137991893) · [Workshop W6 运行](https://github.com/SKYdayDUCK/NovelFactory/actions/runs/43122517485) · [#25 内容差异](https://github.com/SKYdayDUCK/NovelFactory/pull/25/files)

## 证据与适用范围

托管 PG17 套件跳过的 17 个 Linux namespace 用例均可在冻结候选 `50c8c5e` 的原生执行回执按完整节点名找到成功记录，17 项通过、0 跳过。此证据与 #25 托管运行分别记录。[原生角色回执](https://github.com/SKYdayDUCK/NovelFactory/blob/df8bea90fe19ea492220448e07323f63c4e496ea/reports/integration/evidence/W6/candidate-50c8c5e/creative-and-roles/role-namespaces.zip)

`business-coverage.json` 的 14 行需求、76 个映射全部逐条匹配原始 JUnit 的 classname、用例名及参数，确认列出的节点没有 skipped、error 或 failure。每个源 ZIP 及源 XML 都有 SHA-256，输入来源可通过 GitHub artifact URL 复核。以下行说明实测的场景和边界。

| 需求 | 实际业务断言与证据 |
|---|---|
| 岗位全链、通信、人员权限和生命周期 | 四套场景预设联通 author → manager → script → chief → volume → 三名 actor。真实组织 stdio 委托到 NF，独立审核员处理冻结材料，作者通过权限限定的回执读取进展，最后对账。另有真实岗位调任/离职/复职及撤权后未送达消息失败测试。查看矩阵中的 AW、dual、sceneA、sceneB。[场景委托入口](https://github.com/SKYdayDUCK/NovelFactory/blob/98a8bbed289a29d0326454c86dd3db54ac85ae5c/workshop/benchmarks/cross_service_scene.py#L277) |
| WorldRef、事实和角色知识与计划 | NF 主线测试覆盖同一物品的客观历史与角色所信、PLAN 查询能看到尚未落实的节点、仅 BELIEF 的演员不能取得规划材料、演员 HTTP 工具不能变更 plane 或读取另一任务上下文。双服务测试还比较组织目录、他人 BELIEF 和真实角色提示序列。 |
| 时间因果、自主行动、剧情偏离 | 三名演员意图封存、六种返回排列、冲突后的联合裁决、过期因果父节点拒绝换绑。宴会场景在演员偏离原定路径后只重排受影响节点；相关任务失效，无关任务保留。正式提交通过 NF 世界内核。合成文本由确定性测试提供。 |
| 已接受历史、多写者 | 两个独立资源命令可以在同一世界链上接受；争夺同一资源时阻止超分配，严格 head 竞争只能有一个胜者。针对历史纠错，原始版本及修复候选分开保存，CAS 在其他提交抢先进入主线时保护新历史。 |
| 正文接受、有限返工与版本绑定 | 已发生事件多次叙述不重复执行效果，待处理的新效果经过世界正式接受后才可进入正文；不可靠叙述不能创建世界事实。独立评审、同一人不能自批、变更前序后须重交接、相同审美返工无进展被拒、返工达到限额后停止。版本化 Skills 的作用域、撤回及在途任务保留历史版本有实际数据库和 stdio 测试。 |
| 恢复与容量边界 | 真实服务分别使用独立 PostgreSQL；Workshop 离线时 NF 可完成任务，Redis 丢通知时 SQL 仍是权威，丢失回执后按原委托幂等对账。UNKNOWN 保持预留，两个 WAL 目标和合成账单涵盖三个恢复错位情形。10/50/200 × 三种准入策略组成 9 个合成委托单元，配置并发上限 2 时实际峰值仍为 1。原始 AT-30 高压的 50/200 overload 与 1000 开环读继续为 NOT_MET。[历史容量](https://github.com/SKYdayDUCK/NovelFactory/issues/13) |

## 新增的正式接受入口反例

现有用例分别验证了草稿读取的世界前提变化、计划修改后的任务资格，以及正文正式接受的历史隔离。新增的 `test_local_plan_change_between_reconciliation_and_prose_acceptance` 连接这三个阶段中的两个事务边界。在同一 WorldRef 下，两个 writer 对两个独立规划节点写出草稿，两个独立 reviewer 均完成正文提取和服务端 CLEAR 对账。作者随后在採用的新计划中仅更改一个节点。测试通过公开服务入口逐项确认：

1. 受影响的 writer 任务实际进入 STALE，原有 CLEAR 报告提交至正文接受时返回 TASK_NOT_ACCEPTABLE。
2. 无关草稿在原版本证据下可以接受，重复提交取得同一回执。
3. 最终仅存一条正文接受记录；世界 head 仍是原 WorldRef，世界事件数为零。

第一版测试把当前拒绝码误设为 STALE_GENERATION。该节点变为 STALE 时保持原代，实际返回 TASK_NOT_ACCEPTABLE。随后测试尝试以作者身份读取 writer 的私有任务，服务按授权契约拒绝；验证改为用该任务的 writer 身份取得 STALE 状态。两次初始结果均作为本地失败回执保留。测试独立通过的确切 JUnit 为 `plan-prose-current.xml`。本次未修改业务规则、权限或测试阈值。

修正后在启用 fsync、synchronous_commit 的独立临时 PostgreSQL 17.11 集群上重新运行 10 个模块，最终由 pytest 报告 **89 项通过，0 失败，0 错误，0 跳过，265.16 秒**。完整 JUnit 位于 `pg17-world-final.xml`，SHA-256 为 `8c74d57a11981e231565f4d8f242793c11521cece363276b3e482e774395071b`。被测文件 `tests/integration/test_narrative.py` 的 Git blob 为 `35b0dfae8cde99622988daae5b4792cc6e84e6db`。完整来源、两次失败、单项与最终套件结果见 `world-run-receipt.json`。

真实文学质量为 NOT_EVALUATED，P6_REAL_CREATION 保持 BLOCKED_LOCAL_AUTHORIZATION。本页评定的是工程调用、权限、状态及恢复证据。

