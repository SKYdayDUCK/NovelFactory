from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as E
import hashlib,json
out=Path(__file__).resolve().parent
base=out.parents[1]/'phase_a'
nf='13909176667-postgres.zip'
aw='w6_artifacts/workshop-results.zip'
orig='w6_artifacts/workshop-scene-recovery-results.zip'
compare='w6_artifacts/workshop-comparisons.zip'
sources={
 'NF':(nf,'postgres-all.xml',13909176667,43137991893),
 'AW':(aw,'workshop-results.xml',13900334763,43122517485),
 'W4':(aw,'w4-reviews-skills-upgrades.xml',13900334763,43122517485),
 'dual':(aw,'dual-results.xml',13900334763,43122517485),
 'svc':(aw,'dual-service-results.xml',13900334763,43122517485),
 'matrixA':(orig,'capacity-results.xml',13900938944,43122517485),
 'matrixB':(compare,'capacity-results.xml',13901499191,43122517485),
 'sceneA':(orig,'scene-results.xml',13900938944,43122517485),
 'sceneB':(compare,'scene-results.xml',13901499191,43122517485),
 'extra':(orig,'ci-evidence/at43-at49-junit.xml',13900938944,43122517485)}
rules=[
 ('组织管理者、委托后工作进展与幂等恢复',{'dual':['test_author_wakeup_recovers_through_real_nf_project_binding'],'AW':['test_reclaimed_wake_does_not_repeat_project_resume_after_delegation_lookup']}),
 ('雇佣、调任、终止、复职、岗位生命周期与撤权',{'AW':['test_tenure_acl_history_and_reactivation','test_competing_hires_use_postgres_connections','test_handoff_retains_own_past_events_and_checks_the_current_tenure','test_grant_revocation_fences_inflight_body_and_ack','test_sender_credential_revoke_blocks_delivery_with_preserved_receipt']}),
 ('编剧、总导演、卷纲导演、演员与独立审核员协作；组织图与实际通信路由',{'AW':['test_directed_routes_causation_body_and_durable_cursor'],'sceneA':['test_real_delegation_unblocks_banquet_actor'],'sceneB':['test_real_delegation_unblocks_banquet_actor']}),
 ('10/50/200 员工委托积压与准入策略',{'matrixA':['test_logical_delegation_backlog'],'matrixB':['test_logical_delegation_backlog']}),
 ('统一 WorldRef、WORLD/BELIEF/PLAN、作者剧情与演员认知隔离',{'NF':['test_r1_sword_history_owner_holder_destroyed_and_belief','test_plan_adoption_exposes_future_cut_without_effects_or_actor_leak','test_http_actor_cannot_switch_plane_or_read_another_tasks_context','test_actor_receives_only_own_compiled_belief_and_frozen_runtime','test_false_letter_blocks_disjoint_guarded_candidate_before_redis_preserves_belief'],'extra':['test_roster_routing_stays_outside_belief_and_other_actors_prompt']}),
 ('故事时间、事件因果及历史版本',{'NF':['test_exact_causal_parent_reference_is_not_silently_rebound','test_database_rejects_direct_immutable_event_edit','test_r1_b_reviewed_loan_to_gift_preserves_history_and_promotes','test_promotion_cas_preserves_new_canon_and_repair_history']}),
 ('角色自主提案、封存、联合裁决、剧情偏离和局部重规划',{'NF':['test_supervised_sealed_slots_wake_waiting_actor_and_survive_lost_handoff','test_one_author_resume_through_autonomous_banquet','test_three_actor_joint_result_is_atomic_idempotent_and_sealed','test_banquet_absence_pins_reference_and_limits_replanning','test_destroyed_future_prerequisite_fences_immediately_then_replans_locally']}),
 ('角色与多写者并发提交、独立工作共存、同一世界历史',{'NF':['test_guarded_independent_resources_share_one_world_chain','test_strict_head_competing_connections_allow_one','test_all_six_actor_completion_orders_preserve_selected_joint_world','test_shared_resource_rejects_overallocation','test_two_real_writer_tasks_parallel_and_successor_cannot_skip_handoffs','test_write_skew_two_guards_cannot_both_leave']}),
 ('有限返工、冻结审核、自审自批拒绝',{'NF':['test_skip_structure_false_resolution_and_unchanged_aesthetic_loop_are_blocked','test_self_review_does_not_become_independent_approval','test_changed_predecessor_requires_new_successor_handoff_even_after_independent_reviews'],'W4':['test_independence_freeze_evidence_and_bounded_rounds'],'dual':['test_independent_review_uses_original_nf_result_and_single_invoice']}),
 ('Skills 共享、版本绑定、撤回',{'W4':['test_skill_policies_no_capabilities','test_skill_old_hash_remains_history_after_revocation','test_live_skill_scopes_and_immutable_task_history']}),
 ('正文接受及世界正式接受分离',{'NF':['test_text_first_delta_must_use_formal_kernel_acceptance_then_exact_alignment','test_unreliable_reader_disclosure_is_accepted_text_without_world_truth','test_world_event_can_be_narrated_twice_without_effect_reapplication','test_finished_unpublished_draft_fenced_when_its_explicit_world_read_changes','test_release_complete_exact_manifest_idempotency_and_immutable_prior']}),
 ('两套 PG、双 MCP 与权限隔离',{'svc':['test_separate_postgres_authorities','test_both_stdio_services_and_revoked_session']}),
 ('Redis 丢失、重复消息和网络丢回执，原委托幂等',{'AW':['test_postgres_mail_during_redis_outage_and_new_worker_processes'],'NF':['test_outbox_failure_redelivery_and_inbox_atomicity'],'dual':['test_two_live_mcp_servers_recover_accepted_task_after_lost_reply'],'extra':['test_workshop_loss_after_nf_provider_send_preserves_single_execution']}),
 ('UNKNOWN 支出/额度保留、合成调用与两库物理恢复',{'NF':['test_budget_race_unknown_reservation_and_settlement'],'W4':['test_paid_review_cannot_spend_without_hold_or_ignore_unknown'],'dual':['test_physical_pitr_both_directions']})]
art={}; cases={}
for k,(zp,n,aid,run) in sources.items():
 p=base/zp; raw=ZipFile(p).read(n); suite=E.fromstring(raw)
 art[k]=dict(producing_sha='ba892d3a424be39efccb697232a5614b26609cc4' if k=='NF' else '98a8bbed289a29d0326454c86dd3db54ac85ae5c',artifact_id=aid,artifact_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),member=n,member_sha256=hashlib.sha256(raw).hexdigest(),url=f'https://github.com/SKYdayDUCK/NovelFactory/actions/runs/{run}/artifacts/{aid}')
 cases[k]=[(c.get('name'),c.get('classname')+'::'+c.get('name'), 'SKIPPED' if c.find('skipped') is not None else 'FAIL' if c.find('error') is not None or c.find('failure') is not None else 'PASS') for c in suite.iter('testcase')]
rows=[]
for req,tests in rules:
 material=[]
 for source,names in tests.items():
  for name in names:
   matches=[(case,status) for n,case,status in cases[source] if n.split('[')[0]==name]
   assert matches,(source,name)
   for case,status in matches:
    assert status=='PASS',(source,case,status)
    material.append(dict(source=source,node=case,status=status))
 rows.append(dict(requirement=req,executed=material))
new=out/'plan-prose-current.xml'
assert E.fromstring(new.read_bytes()).find('testsuite').get('failures')=='0'
data=dict(base='ba892d3a424be39efccb697232a5614b26609cc4', sources=art, rows=rows, new_regression={'test':'tests.integration.test_narrative::test_local_plan_change_between_reconciliation_and_prose_acceptance','local_junit':new.name,'local_junit_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'postgres':'17.11','status':'PASS','product_code_changed':False}, boundaries=['Original engineering fixture uses local synthetic model endpoints. Literary quality NOT_EVALUATED.','Issue #13 remains NOT_MET. The closed-loop Workshop matrix is independent.','Workshop W6 artifact commit is the immediately preceding main. The #25 diff changes six integration markdown files; the NF tests have their own post-#25 main run.','Paired ledger replay and the two separate live service clusters are distinct tests.'])
(out/'business-coverage.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
print(len(rows),'requirements;',sum(len(r['executed']) for r in rows),'actual JUnit mappings')

