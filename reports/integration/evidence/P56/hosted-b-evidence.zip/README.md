# P5.6 hosted acceptance evidence

PR #26 head `e5f5348ca07dc50c9fe52ab271a733ac31fa063c`. GitHub tested the synthetic merge checkout `fea6519f7d5d24b8f391648f26fee2ce794035ac`. The separate main push ran at `4e8fc5a3c2331a0de669ad8851d82c5b08a1e5dc`. The three commit trees agree. Each checkout has five hosted workflows, including three capacity workflows. See the measured failures in each capacity-measurements.json and the retained job log excerpts. Results from each run retain their actual status. Real literary evaluation was not performed. All model workload measurements here are deterministic, local engineering fixtures.

With Python 3.12, unpack the archive, then run these commands from its root.

    sha256sum --check SHA256SUMS
    python verify_run.py --metadata-dir pr26/workshop --archives pr26/workshop/archives --checkout-sha fea6519f7d5d24b8f391648f26fee2ce794035ac
    python verify_run.py --metadata-dir main-4e8fc5a/workshop --archives main-4e8fc5a/workshop/archives --checkout-sha 4e8fc5a3c2331a0de669ad8851d82c5b08a1e5dc

Each workshop archive is an unmodified Actions ZIP and is bound to the official run, job execution and checkout. NF JUnit, R1 and recovery records are unmodified ZIP members, with artifact ID and source digest recorded in MANIFEST.json. Large capacity archives are represented by their original artifact IDs and SHA256, hashes for each selected raw measurement, fields verified against the original JSON, and failed-job log excerpts. To examine all HTTP samples, fetch the documented upstream artifact ID while GitHub retains it. The long-lived fixture source links and the integration-ref-chain.json identify the exact source commits. The earlier local evidence pack remains separate. The separate-main-local directory contains only the independent post-merge 22-test and PITR replay, with its own checkout and summary; it does not contribute to hosted counts.
