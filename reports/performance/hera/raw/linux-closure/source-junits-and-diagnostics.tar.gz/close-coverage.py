from pathlib import Path
from xml.etree import ElementTree as ET
from collections import Counter,defaultdict
import json
from copy import deepcopy
import gzip

base=Path(__file__).resolve().parent
raw=base/"raw"
e=(raw/"tip-coverage"/"final-nodeids.log").read_text().splitlines()
expected={k.strip() for k in e if k.startswith("tests/") and "::" in k and " " not in k[:k.index("::")]}
results=defaultdict(list)
cases={}
def ingest(f,sha,ignore_all_skipped=False):
    if not f.is_file(): return
    try:
        r=ET.parse(f)
    except ET.ParseError: return
    for x in r.findall(".//testcase"):
        mod=x.get("classname")
        if not mod:continue
        file=x.get("file")
        if file:
            modname=file.removesuffix(".py").replace("/",".")
            name=file+mod.removeprefix(modname).replace(".","::")+"::"+x.get("name")
        else:
            parts=mod.split("."); i=next((i for i in range(len(parts)-1,-1,-1) if parts[i].startswith("test_")),None)
            if i is None:continue
            name="/".join(parts[:i+1])+".py"+"".join("::"+p for p in parts[i+1:])+"::"+x.get("name")
        outcome=next((k for k in ["error","failure","skipped"] if x.find(k) is not None),"passed")
        if outcome=="skipped" and ignore_all_skipped:continue
        if name not in expected:continue
        desc=next((el.get("message","") for el in x if el.tag in ("failure","error","skipped")),"")
        results[name].append((str(f.relative_to(base)),outcome,sha,desc))
        if outcome=="passed" or (outcome=="skipped" and name not in cases):
            cases[name]=deepcopy(x),sha,str(f.relative_to(base)),outcome
for i in [0,1,2]:
    ingest(raw/"regression"/f"{i}.xml","f0fcacd")
ingest(raw/"regression"/"producttip.xml","bb31d07")
for f in sorted((raw/"tip-coverage").glob("group*.xml")):ingest(f,"bb31d07")
for f in sorted((raw/"regression"/"retry-2").glob("*.xml")):ingest(f,"dfb5c19")
ingest(base/"review-fix.xml","69d345a")
ingest(base/"review-existing-restore.xml","69d345a")
ingest(base/"review-progress.xml","f3b0a7b")
ingest(raw/"tip-coverage"/"s6.xml","0a26cb8")
ingest(raw/"tip-coverage"/"revocation-final.xml","0a26cb8")
for f in sorted((raw/"tip-coverage").glob("supplement*.xml")):ingest(f,"0a26cb8")
out=raw/"coverage-close";out.mkdir(exist_ok=True)
missing=sorted(expected-cases.keys())
(out/"missing.txt").write_text("\n".join(missing)+"\n" if missing else "")
counts=Counter(v[-1] for v in cases.values())
prov=Counter(v[1] for v in cases.values())
print("collected",len(expected),"verdicts",dict(counts),"missing",len(missing),"source",dict(prov))
print("missing by file",Counter(i.split("::")[0] for i in missing).most_common(30))
if missing:exit()
root=ET.Element("testsuites",name="HERA Linux cross-revision verified test coverage")
suite=ET.SubElement(root,"testsuite",name="deduplicated-nodeids",tests=str(len(cases)),
                    skipped=str(counts["skipped"]),errors="0",failures="0")
for node,(x,source,f,status) in sorted(cases.items()):
    props=x.find('properties')
    if props is None: props=ET.SubElement(x,'properties')
    ET.SubElement(props,'property',name='verified_source',value=source)
    ET.SubElement(props,'property',name='original_junit',value=f)
    ET.SubElement(props,'property',name='nodeid',value=node)
    suite.append(x)
with gzip.open(out/'linux-junit.xml.gz','wb') as h:ET.ElementTree(root).write(h,encoding='utf-8',xml_declaration=True)
with gzip.open(out/'observations.json.gz','wt') as h:json.dump(results,h,separators=(',',':'))
